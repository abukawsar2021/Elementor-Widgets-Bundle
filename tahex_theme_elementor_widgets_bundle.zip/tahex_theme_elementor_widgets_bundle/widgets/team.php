<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Team extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-team';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Team', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-user-circle-o';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'team_section_content',
			[
				'label' => __( 'Team Section Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'team_image',
			[
				'label' => __( 'Team Single Image', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		
		
		
   
   
        $this->add_control(
			'name_title',
			[
				'label' => __( 'Name Title', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title #1', 'plugin-domain' ),				
			]
		);
		
		$this->add_control(
			'position_title',
			[
				'label' => __( 'Position Title', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title #1', 'plugin-domain' ),				
			]
		);
		
		$this->add_control(
			'profile_title',
			[
				'label' => __( 'Profile Title', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title #1', 'plugin-domain' ),				
			]
		);
				
		$this->end_controls_section();
		$this->start_controls_section(
			'team_section_style',
			[
				'label' => __( 'Team Item Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'team_iteam_padding',
			[
				'label' => __( 'Item Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'team_item_caption_margin',
			[
				'label' => __( 'Caption Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'team_iteam_caption_padding',
			[
				'label' => __( 'Caption Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
	    $this->end_controls_section();
		
		
		$this->start_controls_section(
			'team_title_caption_style',
			[
				'label' => __( 'Title Caption Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		
		$this->add_control(
			'team_title_caption_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper  .single-team-item-caption .title-caption' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		
		$this->add_control(
			'team_title_caption_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper  .single-team-item-caption .title-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'team_title_caption_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .title-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'team_title_caption_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .title-caption' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'team_name_title_color',
			[
				'label' => __( 'Name Title Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .title-caption h4' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_title_typography',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .title-caption h4',
			]
		);
		
		
		$this->add_control(
			'team_position_title_color',
			[
				'label' => __( 'Position Title Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .title-caption p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'position_title_typography',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .title-caption p',
			]
		);
		
	    $this->end_controls_section();
		
		
		$this->start_controls_section(
			'team_profile_caption_style',
			[
				'label' => __( 'Profile Caption Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'team_profile_caption_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper  .single-team-item-caption .profile-caption' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'team_profile_caption_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper  .single-team-item-caption .profile-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'team_profile_caption_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .profile-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'team_profile_caption_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .profile-caption' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'team_profile_caption_title_color',
			[
				'label' => __( 'Name Title Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .profile-caption .profile-title h4' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_profile_caption_title_typography',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-team-item-wrapper .single-team-item-caption .profile-caption .profile-title h4',
			]
		);
		
		$this->end_controls_section();
		
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();
	?>
	     <div class="wow slideInLeft" data-wow-duration="1s" data-wow-delay=".1s">
			<figure class="single-team-item-wrapper team-link" data-link="team1.html">					  
				<img class="img-responsive" src="<?php echo wp_get_attachment_image_url($settings['team_image']['id'],'full');?>" alt="" />
					<figcaption class="single-team-item-caption">	
						<div class="title-caption">								
							<h4 class="name-title"> <?php echo ( $settings['name_title']);?> </h4>
							<p class="position-title">  <?php echo ( $settings['position_title'] );?> </p>	
						</div><!--title-caption-->
						<div class="profile-caption">								
							<h4 class="profile-title"> <?php echo ( $settings['profile_title'] );?> </h4>
						</div><!--profile-caption-->									
					</figcaption><!--single-team-item-caption-->
			</figure>	<!--single-team-item-wrapper-->
		</div><!--/.col-md-4-->
				
                        
		<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

