<?php

namespace TahexPlugin\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


class Tahex_Slider extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'slider';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Slider', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-slideshow';
	}
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'slider_section',
			[
				'label' => __( 'Slider Section', 'tahex_plg' ),
			]
		);
	
    $this->add_control(
			'slider_settings',
			[
				'label' => __( 'Slider Settings', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		
		
		
	
	$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'slider_sub_title', [
				'label' => __( 'Slider Sub Title', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Slider Sub Title' , 'tahex_plg' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'slider_title', [
				'label' => __( 'Slider Title', 'tahex_plg' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Slider Title' , 'tahex_plg' ),
				'show_label' => true,
			]
		);
		
	
		$repeater->add_control(
			'slider_image', [
				'label' => __( 'Add Slider Image', 'tahex_plg' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'show_label' => true,
			]
		);
		
		$this->add_control(
			'slider_list',
			[
				'label' => __( 'Slider List', 'tahex_plg' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'slider_sub_title' => __( 'This is subtitle 1 ', 'tahex_plg' ),
						'slider_title' => __( 'This is title 1', 'tahex_plg' ),
						
					],
					[
						'slider_sub_title' => __( 'This is subtitle 2', 'tahex_plg' ),
						'slider_title' => __( 'This is title1', 'tahex_plg' ),
					],
				],
				
			]
		);
		
		
	$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Slider Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,			
					'px' => [
						'min' => 800,
						'max' => 950,
					],				
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-item' => 'min-height:{{SIZE}}{{UNIT}};',
				],
			]
		);
		
	$this->add_control(
			'title_subtitle_settings',
			[
				'label' => __( 'Subtitle & Title Settings', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		

	$this->add_control(
			'slider_sub_title',
			[
				'label' => __( 'Show / Hide Subtitle','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'label_on' => __( 'Show','tahex_plg' ),
					'label_off' => __( 'Hide','tahex_plg' ),
				],
				'default' => 'yes',
			]
		);	
		
	$this->add_control(
			'slider_title',
			[
				'label' => __( 'Show / Hide Title','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'show' => __( 'Show','tahex_plg' ),
					'hide' => __( 'Hide','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);	
		
		
		$this->add_control(
			'slider_content',
			[
				'label' => __( 'Show / Hide Content','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'show' => __( 'Show','tahex_plg' ),
					'hide' => __( 'Hide','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);	
	
	
	$this->end_controls_section();
	
	$this->start_controls_section(
			'border_settings',
			[
				'label' => __( 'Border Settings', 'tahex_plg' ),
			]
		);	
	$this->add_control(
			'top_border',
			[
				'label' => __( 'Top Border Settings', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);	

	$this->add_control(
			'show_top_border',
			[
				'label' => __( 'Show / Hide','tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'show' => __( 'Show','tahex_plg' ),
					'hide' => __( 'Hide','tahex_plg' ),
				],
				'default' => 'show',				
			]
		);
		
	 $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'style_top_border',
				'selector' => '{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading span',
				'separator' => 'before',
				'default' => 'none',
				'condition' => [
					'show_top_border' => 'show',
				],
			]
		);	

	
    $this->add_responsive_control(
			'width_top_border',
			[
				'label' => __( 'Width', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],				
				],
				'condition' => [
					 'show_top_border' => 'show',
				 ],
				'selectors' => [
					'{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading span' => 'width:{{SIZE}}{{UNIT}};',
				],				
			]
		);

	 $this->add_responsive_control(
			'margin_top_top_border',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'condition' => [
					 'show_top_border' => 'show',
				 ],
				'selectors' => [
					'{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading span' => 'margin-top:{{SIZE}}{{UNIT}};',
				],
			]
		);
			

		$this->add_responsive_control(
			'margin_bottom_top_border',
			[
				'label' => __( 'Margin Bottom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'condition' => [
					 'show_top_border' => 'show',
				 ],
				'selectors' => [
					'{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading span' => 'margin-bottom:{{SIZE}}{{UNIT}};',
				],
			]
		);
	$this->add_control(
			'bottom_border_settings',
			[
				'label' => __( 'Bottom Border Settings', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		
	
	$this->add_control(
			'show_bottom_border',
			[
				'label' => __( 'Show / Hide ','tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'block' => __( 'Show','tahex_plg' ),
					'none' => __( 'Hide','tahex_plg' ),
				],
				'default' => 'block',
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-content-wrapper h1.slider-heading:after' => 'display: {{VALUE}};',
				],
			]
		);	
		
	 $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'style_bottom_border',
				'selector' => '{{WRAPPER}} .home-sliders .single-slide-content-wrapper h1.slider-heading:after',
				'separator' => 'before',
				'condition' => [
					'show_bottom_border' => 'block',
				],
			]
		);	
		
	$this->add_responsive_control(
			'width_bottom_border',
			[
				'label' => __( 'Width', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],				
				],
				'condition' => [
					 'show_bottom_border' => 'block',
				 ],
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-content-wrapper h1.slider-heading:after'=> 'width:{{SIZE}}{{UNIT}};',
				],				
			]
		);	
		
		
	$this->end_controls_section();	
	
	$this->start_controls_section(
			'addition_settings',
			[
				'label' => __( 'Addional Settings', 'tahex_plg' ),
			]
		);
		
		
	$this->add_control(
			'animation_settings',
			[
				'label' => __( 'Animation Settings', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
	);	
	
		
		
		
		$this->add_control(
			'animation',
			[
				'label' => __( 'Animation', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'slide',
				'options' => [
					'yes' => __( 'Yes', 'tahex_plg' ),
					'no' => __( 'No', 'tahex_plg' ),
				],
				'default' => 'false',
				'frontend_available' => true,
			]
		);
		

		
	$this->add_control(
			'arrow_settings',
			[
				'label' => __( 'Arrow', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);			
		
		$this->add_control(
			'arrows',
			[
				'label' => __( 'Show / Hide ','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'yes' => __( 'Yes','tahex_plg' ),
					'no' => __( 'No','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
	 $this->add_control(
			'arrow_margin_left',
			[
				'label' => __( 'Margin Left', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-nav' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'arrows' => 'yes',
				],
			]
		);

	$this->add_control(
				'arrow_margin_right',
				[
					'label' => __( 'Margin Right', 'tahex_plg' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 20,
							'max' => 500,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .owl-nav' => 'right: {{SIZE}}{{UNIT}};',
					],
					'condition' => [
						'arrows' => 'yes',
					],
				]
			);

      

		$this->add_control(
			'arrow_margin_top',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-nav' => 'top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'arrows' => 'yes',
				],
			]
		);
		
		$this->add_control(
			'arrow_margin_bottom',
			[
				'label' => __( 'Margin Bottom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-nav' => 'bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'arrows' => 'yes',
				],
			]
		);
		
		
    $this->add_control(
			'dots_settings',
			[
				'label' => __( 'Dots', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		

		
		$this->add_control(
			'dots',
			[
				'label' => __( 'Show / Hide ','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'label_on' => __( 'Yes','tahex_plg' ),
					'label_off' => __( 'No','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'dots_width',
			[
				'label' => __( 'Width', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-dots' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'dots' => 'yes',
				],
			]
		);
		
		
	 $this->add_control(
			'dots_margin_left',
			[
				'label' => __( 'Margin Left', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-dots' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'dots' => 'yes',
				],
			]
		);
		
		
	$this->add_control(
			'dots_margin_top',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-dots' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'dots' => 'yes',
				],
			]
		);		
		
		
		
	$this->add_control(
			'mouse_drag_settings',
			[
				'label' => __( 'Mouse Drag', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);			
	
	$this->add_control(
			'mousedrag',
			[
				'label' => __( 'Yes / No ','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'label_on' => __( 'Yes','tahex_plg' ),
					'label_off' => __( 'No','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
	
    $this->add_control(
			'autoplay_settings',
			[
				'label' => __( 'Autoplay', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);			
	
	$this->add_control(
			'autoplay',
			[
				'label' => __( 'Yes / No ','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'label_on' => __( 'Yes','tahex_plg' ),
					'label_off' => __( 'No','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
	$this->add_control(
			'slider_speed',
			[
				'label' => __( 'Slider Speed', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		
		
    $this->add_control(
			'speed',
			[
				'label' => __( 'Slider Speed', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 5000,
				'render_type' => 'none',
				'frontend_available' => true,
			]
		);		


    $this->add_control(
			'loop_settings',
			[
				'label' => __( 'Loop', 'tahex_plg' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);			
	
	$this->add_control(
			'loop',
			[
				'label' => __( 'Yes / No ','tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'options' => [
					'label_on' => __( 'Yes','tahex_plg' ),
					'label_off' => __( 'No','tahex_plg' ),
				],
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);



	
	$this->end_controls_section();
	
	$this->start_controls_section(
		'subtitle_section',
		[
			'label' => __( 'Subtitle Settings', 'tahex_plg' ),
			'tab' => Controls_Manager::TAB_STYLE,
		]
	);

	$this->add_control(
			'subtitle_align',
			[
				'label' => __( 'Align ', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .slider-sub-heading' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		
		
	
	$this->add_control(
			'subtitle_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .slider-sub-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	

	$this->add_control(
			'subtitle_top_padding',
			[
				'label' => __( 'Padding Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .slider-sub-heading' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
	$this->add_control(
			'subtitle_bottom_padding',
			[
				'label' => __( 'Padding Bottom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .slider-sub-heading' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
	$this->add_control(
			'subtitle_color',
			[
				'label' => __( 'Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider-sub-heading' => 'color: {{VALUE}}',
				],
			]
		);

	
	    $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'label' => __( 'Subtitle Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .slider-sub-heading',
			]
		);

	$this->end_controls_section();
	
	$this->start_controls_section(
		'title_section',
		[
			'label' => __( 'Title Settings', 'tahex_plg' ),
			'tab' => Controls_Manager::TAB_STYLE,
		]
	);
	
	
	$this->add_control(
			'title_align',
			[
				'label' => __( 'Align ', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .slider-heading' => 'text-align: {{VALUE}};',
				],
			]
		);
	
	
	$this->add_control(
			'title_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .slider-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
		
	
	$this->add_control(
			'title_top_padding',
			[
				'label' => __( 'Padding Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .slider-heading' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
	$this->add_control(
			'title_bottom_padding',
			[
				'label' => __( 'Padding Bottom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .slider-heading' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
	
		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider-heading' => 'color: {{VALUE}}',
				],
			]
		);

	
	    $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Title Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .slider-heading',
			]
		);
		
	
	$this->end_controls_section();
	

	
	$this->start_controls_section(
		'dots_style',
		[
			'label' => __( 'Dots Settings', 'tahex_plg' ),
			'tab' => Controls_Manager::TAB_STYLE,
		]
	);
	
	
	$this->add_control(
			'dot_style',
			[
				'label' => __( 'Dot Style', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'frontend_available' => true,				
			]			
		);
		

	$this->add_control(
			'dot_size',
			[
				'label' => __( 'Size', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .home-sliders .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'dot_style' => 'yes',
				],
			]
		);
	
	
		
	$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'Border',
				'selector' => '{{WRAPPER}} .owl-dot',
				'condition' => [
					'dot_style' => 'yes',
				],

			]
		);
		
	$this->add_control(
			'dot_border_radius',
			[
				'label' => __( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'dot_style' => 'yes',
				],
			]
			
		);

	
	$this->add_control(
			'dot_bg_color',
			[
				'label' => __( 'BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .home-sliders .owl-dot' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'dot_style' => 'yes',
				],
			]
		);
   $this->add_control(
			'dot_bg_active_color',
			[
				'label' => __( 'BG Active Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .home-sliders .owl-dot.active' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'dot_style' => 'yes',
				],
			]
			
		);

	$this->end_controls_section();
	
	
		$this->start_controls_section(
		'arrows_style',
		[
			'label' => __( 'Arrows Settings', 'tahex_plg' ),
			'tab' => Controls_Manager::TAB_STYLE,
		]
	);
	
	$this->add_control(
			'arrow_style',
			[
				'label' => __( 'Arrow Style', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'frontend_available' => true,				
			]			
		);
		
		
	$this->add_control(
			'arrow_size',
			[
				'label' => __( 'Size', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .home-sliders .owl-nav' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'arrow_style' => 'yes',
				],
			]
		);	
		
		
		
	
	$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'Arrow Border',
				'selector' => '{{WRAPPER}} .owl-nav .owl-prev, .owl-nav .owl-next',
				'condition' => [
					'arrow_style' => 'yes',
				],

			]
		);
		
	$this->add_control(
			'arrow_border_radius',
			[
				'label' => __( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .owl-nav .owl-prev, .owl-nav .owl-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'arrow_style' => 'yes',
				],
			]
			
		);
	
	$this->add_control(
			'arrow_line_height',
			[
				'label' => __( 'Line Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-nav .owl-prev, .owl-nav .owl-next' => 'line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'arrow_style' => 'yes',
				],
			]
		);	
	
	
	
	$this->end_controls_section();
	
	
	$this->start_controls_section(
		'slider_overlay',
		[
			'label' => __( 'Slider Overlay', 'tahex_plg' ),
			'tab' => Controls_Manager::TAB_STYLE,
		]
	);
	
	$this->add_control(
			'show_overlay',
			[
				'label' => __( 'Show / Hide', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'frontend_available' => true,				
			]			
		);
	
	$this->add_control(
			'slider_overlay_bg_color',
			[
				'label' => __( 'Overlay Bg Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-item::after' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_overlay' => 'yes',
				],
			]
		);
	$this->add_control(
			'slider_overlay_bg_color_opacity',
			[
				'label' => __( 'Opacity', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-item::after' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'show_overlay' => 'yes',
				],
			]
		);	
	

	$this->end_controls_section();
	
	$this->start_controls_section(
			'scroll_down_arrow_settings',
			[
				'label' => __( 'Down Arrow Settings', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
	
	$this->add_control(
			'down_arrow_show',
			[
				'label' => __( 'Show / Hide', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
	$this->add_control(
			'scroll_to_sec',
			[
				'label' => __( 'Scroll to Section Name', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'work',
				'condition' => [
					'down_arrow_show' => 'yes',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);
		

$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .down-arrow',
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);

 
$this->add_control(
			'd_arrow_width_height',
			[
				'label' => __( 'Width & Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .down-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);

	$this->add_control(
			'd_arrow_border_radius',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .down-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);
	
	
	
	$this->add_control(
			'd_arrow_icon_size',
			[
				'label' => __( 'Arrow Icon Size', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .down-arrow>i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);
		
		
		
		$this->add_control(
			'd_arrow_icon_color',
			[
				'label' => __( 'Icon Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .down-arrow>i' => 'color: {{VALUE}};',
				],
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'd_arrow_icon_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .down-arrow' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);
		
		
		$this->add_control(
			'd_arrow_icon_hover_color',
			[
				'label' => __( 'Hover Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .down-arrow:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'down_arrow_show' => 'yes',
				],
			]
		);
	
		$this->end_controls_section();


	}

	
	
	
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
    $settings = $this->get_settings_for_display();
	
     if($settings['slider_list']){
		 $dynamic_id = rand(15212,258741);
		 if(count($settings['slider_list']) > 1){

               if($settings['dots'] ==  'yes'){
				   $dots = 'true';				   
			   }else{
				    $dots = 'false';
			   }			   
			    if($settings['arrows'] ==  'yes'){
				   $arrows = 'true';				   
			   }else{
				    $arrows = 'false';
			   }
			   if($settings['mousedrag'] ==  'yes'){
				   $mousedrag = 'true';				   
			   }else{
				    $mousedrag = 'false';
			   }
			   
			    if($settings['autoplay'] ==  'yes'){
				   $autoplay = 'true';				   
			   }else{
				    $autoplay = 'false';
			   }
			   
			    if($settings['speed'] ==  'yes'){
				   $speed = 'true';				   
			   }else{
				    $speed = 'false';
			   }
			   
			   if($settings['loop'] ==  'yes'){
				   $loop = 'true';				   
			   }else{
				    $loop = 'false';
			   }
			   
			  if($settings['animation'] ==  'yes'){
				   $fadeIn = 'fadeIn';				   
			   }else{
				    $fadeIn = '';
			   }
			   
			    if($settings['animation'] ==  'yes'){
				   $fadeOut = 'fadeOut';				   
			   }else{
				    $fadeOut = '';
			   } 
			   
			   
			   
			 ?>
			 <script type="text/javascript">
				jQuery(document).ready(function($){
					
					var homeSlider = $('.home-sliders');
					homeSlider.owlCarousel({
						items: 1,
						loop: <?php echo $loop ?>,
						autoplayTimeout: <?php echo $settings['speed'] ?>,
						autoplay: <?php echo $autoplay ?>,
						animateIn:'<?php echo $fadeIn ?>',
						animateOut:'<?php echo $fadeOut ?>',
						mouseDrag:<?php echo $mousedrag ?>,
						dots: <?php echo $dots ?>,
						nav:  <?php echo $arrows ?>,
						navText: ["<i class='zmdi zmdi-chevron-left'></i>",
							"<i class='zmdi zmdi-chevron-right'></i>"
						]
					});			
					
				});
		   
	         </script>		 
		<?php }
	 }
	?>
	   

	  
	  	<!-- START-SLIDER -->

	<section id="slider_list-<?php echo $dynamic_id ?>" class="home-sliders owl-carousel">
	
	 <?php  foreach( $settings['slider_list'] as $slider ):?>
	 
		<div style="background-image:url(<?php echo esc_url ( wp_get_attachment_image_url($slider['slider_image']['id'],'large') ) ;?>);" class="single-slide-item slide-bg-1">
		
			<div class="single-slide-content-wrapper">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
						    <h2 class="slider-sub-heading"> 							
								 <?php
								 if(!empty($settings['slider_sub_title'])){
									 if( 'yes' === $settings['slider_sub_title'] ){
									   echo wp_kses_post( $slider['slider_sub_title']);
									 }
								 }
								  
								 ?>  
								 
								 <?php if($settings['show_top_border'] == 'show'){?>							 
									  <span></span>								  
								<?php } ?>

						    </h2>
							<h1 class="slider-heading">
							
								<?php
								if(!empty($settings['slider_title'])){
									if('yes' === $settings['slider_title']){
										echo wp_kses_post($slider['slider_title'] );
									}	
								}	
								
							?> 
							</h1>	
						</div>
					</div><!--/.row-->
				</div><!--/.container-->
			</div><!--single-slide-content-wrapper-->
		</div><!--single-slide-item-->
		
		
		 <?php endforeach;?>
		
		 
	</section><!-- sliders -->
	
	 <?php if( 'yes' == $settings['down_arrow_show']):?>
		   
             <a class="down-arrow section-scroll hidden-xs" href="#<?php echo $settings['scroll_to_sec']?>">
			    <i class="zmdi zmdi-chevron-down zmd-fw animated infinite pulse"></i>
			 </a>
	    
	        <?php endif;?>
	
	<!-- END-SLIDER -->
	  

	<?php  
	}



}
