<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Ticker_Slider extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-ticker-slider';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Ticker Slider', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-slider-3d';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Slogan Ticker Slider Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$repeater = new \Elementor\Repeater();
        
		$repeater->add_control(
			'slogan_title', [
				'label' => __( 'Title', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		


		$this->add_control(
			'slogan_list',
			[
				'label' => __( 'Title List', 'tahex_plg' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'slogan_title' => __( 'Slogan Title #1', 'tahex_plg' ),
					],
                    [
						'slogan_title' => __( 'Slogan Title #2', 'tahex_plg' ),
					],
                    [
						'slogan_title' => __( 'Slogan Title #3', 'tahex_plg' ),
					],					
					
	
				],
				'title_field' => '{{{ slogan_title }}}',
			]
		);
		
		
		
		$this->add_control(
			'slogan_btn_text',
			[
				'label' => __( 'Button Text', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Button 1' , 'tahex_plg' ),
				'label_block' => true,
				
			]
		);
		

		$this->end_controls_section();
		
		$this->start_controls_section(
			'slogan_ticker_content_style',
			[
				'label' => __( 'Slogan Ticker Content Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'slogan_content_align',
			[
				'label' => __( 'Alignment', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .single-slogan-content' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'slogan_content_margin_top',
			[
				'label' => __( 'Margin Top', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .single-slogan-content' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'slogan_content_margin_bottom',
			[
				'label' => __( 'Margin Bottom', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .single-slogan-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .slogan-box-wrapper .single-slogan-content h1',
			]
		);


        $this->end_controls_section();

	    $this->start_controls_section(
			'slogan_ticker_button_style',
			[
				'label' => __( 'Slogan Ticker Button Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'slogan_btn_align',
			[
				'label' => __( 'Button Align', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'slogan_btn_text_align',
			[
				'label' => __( 'Button Text Align', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap .slogan-btn' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'slogan_btn_width',
			[
				'label' => __( 'Width', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'slogan_btn_height',
			[
				'label' => __( 'Height', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		
		$this->add_control(
			'slogan_btn_margin_top',
			[
				'label' => __( 'Margin Bottom', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'slogan_btn_margin_left',
			[
				'label' => __( 'Margin Left', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'slogan_btn_margin_right',
			[
				'label' => __( 'Margin Right', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		$this->add_control(
			'slogan_btn_padding',
			[
				'label' => __( 'Padding', 'plugin-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'slotan_btn_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap .slogan-btn',
			]
		);
		
		$this->add_control(
			'slotan_btn_bg_color',
			[
				'label' => __( 'Background Color', 'plugin-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'slotan_btn_text_color',
			[
				'label' => __( 'Text Color', 'plugin-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'color: {{VALUE}}',
				],
			]
		);

       $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'slogan_btn_border',
				'label' => __( 'Border', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn',
			]
		);
		
		
		$this->add_control(
			'slotan_btn_border_radius',
			[
				'label' => __( 'Border Radius', 'plugin-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'slotan_btn_bg_color_on_hover',
			[
				'label' => __( 'Background Hover Color', 'plugin-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'slotan_btn_text_color_on_hover',
			[
				'label' => __( 'Text Hover Color', 'plugin-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-btn-wrap a.slogan-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);


		
		$this->end_controls_section();
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();
	?>
	  
				<div id="post-<?php echo get_the_ID(); ?>" class="slogan-box-wrapper">

						<ul class="single-slogan-content list-unstyled">
						
						    <?php  if ( $settings['slogan_list'] ) {

                                foreach( $settings['slogan_list'] as $slogan){ ?>
								
								   <li><h1> <?php echo ( $slogan['slogan_title'] );?> </h1></li>
								
						    <?php } 
							 } 
							?>
							
						</ul>
						<div class="pdt-10"></div>
						<div class="slogan-btn-wrap">
							<a href="#<?php echo strtolower( $settings['slogan_btn_text']);?>" class="section-scroll slogan-btn"><i class="zmdi zmdi-chevron-right"></i> 
							   <?php echo ( $settings['slogan_btn_text'] );?>
							</a>
						</div>
				</div>	<!--slogan-box-wrapper-->				

                        
		<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

