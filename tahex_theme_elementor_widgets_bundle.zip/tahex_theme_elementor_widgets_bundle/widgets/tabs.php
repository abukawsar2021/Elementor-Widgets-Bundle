<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Tabs extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-tabs-abt';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Tabs', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-tabs';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	/**
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'tab_section',
			[
				'label' => __( 'Tab  Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
			
        $repeater = new Repeater();
		
		$repeater->add_control(
			'src_type',
			[
				'label' => __( 'Source Type', 'tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'image',
				'options' => [
					'image' => __( 'Single Image', 'tahex_plg' ),
					'slider' => __( 'Slider', 'tahex_plg' ),
					'lightbox' => __( 'Lightbox with Youtube', 'tahex_plg' ),
					'youtube' => __( 'YouTube Video', 'tahex_plg' ),
					'gmap' => __( 'Google Map', 'tahex_plg' ),
					'contact' => __( 'Contact Form', 'tahex_plg' ),
				],
				'frontend_available' => true,
			]
		);
		
		$repeater->add_control(
			'tab_image',
			[
				'label' => __( 'Image', 'tahex_plg' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'src_type' => 'image',
				],
				'frontend_available' => true,
			]
		);
		
		$repeater->add_control(
			'tab_slider',
			[
				'label' => __( 'Add Slider Images', 'tahex_plg' ),
				'type' => Controls_Manager::GALLERY,
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'src_type' => ['slider', 'contact']
				],
				'frontend_available' => true,
			]
		);
		
		$repeater->add_control(
			'tab_lightbox_image',
			[
				'label' => __( 'Lightbox Image', 'tahex_plg' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'src_type' => 'lightbox',
				],
				'frontend_available' => true,
			]
		);
		
		$repeater->add_control(
			'tab_lightbox_video_url',
			[
				'label' => __( 'Lightbox Video Link', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'https://www.youtube.com/embed/b7BzAsOCq1M',
				'description' => __( 'Add Video Embed url here, otherwise video not working', 'tahex_plg' ),
				'label_block' => true,
				'condition' => [
					'src_type' => 'lightbox',
				],
				'frontend_available' => true,
			]
		);

		$repeater->add_control(
			'youtube_url',
			[
				'label' => __( 'Link', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your URL', 'tahex_plg' ) . ' (YouTube)',
				'default' => 'https://www.youtube.com/embed/b7BzAsOCq1M',
				'label_block' => true,
				'condition' => [
					'src_type' => 'youtube',
				],
				'frontend_available' => true,
			]
		);
		

		$repeater->add_control(
			'tab_title',
			[
				'label' => __( 'Title', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Tab Title', 'tahex_plg' ),
				'placeholder' => __(tahex_plg),
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		
		$repeater->add_control(
			'tab_sub_title',
			[
				'label' => __( 'Subtitle', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Tab Subtitle', 'tahex_plg' ),
				'placeholder' => __(tahex_plg),
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		
		
		$repeater->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'tahex_plg' ),
				'default' => __( 'Tab Content', 'tahex_plg' ),
				'placeholder' => __( 'Tab Content', 'tahex_plg' ),
				'type' => Controls_Manager::WYSIWYG,
				'show_label' => false,
			]
		);
		

		$repeater->add_control(
			'tabs_items_column',
			[
				'label' => __( 'Item Column', 'tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12'  => __( 'One Column', 'tahex_plg' ),
					'col-md-6' => __( 'Two Column', 'tahex_plg' ),
				],
				'condition' => [
					'src_type' => ['image','slider','lightbox','youtube',]
				],
				
			]
		);

		$repeater->add_control(
			'tabs_items_column_map_form',
			[
				'label' => __( 'Map & Form Column', 'tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'col-md-12',
				'options' => [
					'col-md-12'  => __( 'One Column', 'tahex_plg' ),
					'col-md-6' => __( 'Two Column', 'tahex_plg' ),
				],
				'condition' => [
					'src_type' => ['gmap','contact',]
				],
			]
		); 
		
		
		$repeater->add_control(
			'tabs_items_position_change',
			[
				'label' => __( 'Content Position Exchange', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [
					'tabs_items_column' => ['col-md-6',]
				],
			]
			
		);
		
		
		$repeater->add_control(
			'tabs_items_column_gap_right_left',
			[
				'label' => __( 'Item Column Gap', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'max' => 100,
					],
					'%' => [
						'min' => 10,
						'step' => 0.1,
					],
					'vw' => [
						'max' => 10,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .column-gap' => 'margin-right: {{SIZE}}{{UNIT}}; margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'tabs_items_column' => ['col-md-6']
				],
			]
		);
		
		
		$repeater->add_control(
			'tabs_items_column_gap_bottom',
			[
				'label' => __( 'Item Column Gap', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'max' => 100,
					],
					'%' => [
						'min' => 10,
						'step' => 0.1,
					],
					'vw' => [
						'max' => 10,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .column-gap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'tabs_items_column' => 'col-md-12',
				],
			]
		);
		
		$repeater->add_control(
			'show_subtitle_bottom_border',
			[
				'label' => __( 'Show Subtitle Bottom Border', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
				
			]
		);
		
		
		  $repeater->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'subtitle_border',
				'label' => __( 'Select Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} span.profile-border',
				'condition' => [
					'show_subtitle_bottom_border' => 'yes',
				],
			]
		); 
		
		$this->add_control(
			'tabs_items',
			[
				'label' => __( 'Tabs Items', 'tahex_plg' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'tab_title' => __( 'Title-1', 'tahex_plg' ),
						'tab_sub_title' => __( 'Subtitle-1', 'tahex_plg' ),
						'tab_content' => __( 'Tab Content One', 'tahex_plg' ),
					],
					[
						'tab_title' => __( 'Title-2', 'tahex_plg' ),
						'tab_sub_title' => __( 'Subtitle-2', 'tahex_plg' ),
						'tab_content' => __( 'Tab Content Two', 'tahex_plg' ),
					],				
				],
				'title_field' => '{{{ tab_title }}}',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'contact_icon_list',
			[
				'label' => __( 'Contact Us Icon List', 'tahex_plg' ),
				
			]
		);
		
		$IconRepeater = new Repeater();

		$IconRepeater->add_control(
			'text',
			[
				'label' => __( 'Text', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __( 'List Item', 'tahex_plg' ),
				'default' => __( 'List Item', 'tahex_plg' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$IconRepeater->add_control(
			'selected_icon',
			[
				'label' => __( 'Icon', 'tahex_plg' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
				
			]
		);

		$IconRepeater->add_control(
			'link',
			[
				'label' => __( 'Link', 'tahex_plg' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'https://your-link.com', 'tahex_plg' ),
			]
		);

		$this->add_control(
			'icon_list',
			[
				'label' => __( 'Icon Item', 'tahex_plg' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $IconRepeater->get_controls(),
				'default' => [
					[
						'text' => __( 'Icon Item #1', 'tahex_plg' ),
						'selected_icon' => [
							'value' => 'fas fa-check',
							'library' => 'fa-solid',
						],
					],
					[
						'text' => __( 'Icon Item #2', 'elementor' ),
						'selected_icon' => [
							'value' => 'fas fa-times',
							'library' => 'fa-solid',
						],
					],
					[
						'text' => __( 'Icon Item #3', 'tahex_plg' ),
						'selected_icon' => [
							'value' => 'fas fa-dot-circle',
							'library' => 'fa-solid',
						],
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);
		
		$this->end_controls_section();

		
		$this->start_controls_section(
			'tab_content_style',
			[
				'label' => __( 'Tab Content Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'site_tab_content_box_shadow',
				'label' => __( 'Box Shadow', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .site-tab-content',
			]
		);
		
		$this->add_control(
			'site_tab_content_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .site-tab-content' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'site_tab_content_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .site-tab-content',
			]
		);
		
		$this->add_control(
			'site_tab_content_pad',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .site-tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->end_controls_section();
		$this->start_controls_section(
			'tab_subtitle_style',
			[
				'label' => __( 'Tab Subtitle Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
	
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_subtitle_typo',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} h2.profile-info-heading',
			]
		);
		
		$this->add_control(
			'text_subtitle_color',
			[
				'label' => __( 'Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h2.profile-info-heading' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'text_subtitle_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h2.profile-info-heading' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'tab_border_btm_style',
			[
				'label' => __( 'Bottom Border Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		
		$this->add_control(
			'subtitle_bottom_border_w',
			[
				'label' => __( 'Width', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .profile-border' => 'width:{{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'subtitle_bottom_border_pos',
			[
				'label' => __( 'Alignment', 'tahex_plg' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .profile-border' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .profile-border' => 'margin: 0 auto; margin-{{VALUE}}: 0',
				],
			]
		);
		
		$this->add_control(
			'subtitle_bottom_border_mt',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} h2.profile-info-heading' => 'margin-bottom:{{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'subtitle_bottom_border_mb',
			[
				'label' => __( 'Margin Bottom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .profile-info-para' => 'margin-bottom:{{SIZE}}{{UNIT}};',
				],
			]
		);
		
		

		 $this->end_controls_section();
		 $this->start_controls_section(
			'tab_inner_content_style',
			[
				'label' => __( 'Inner Content Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'site_tab_inner_content_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .tab-pane ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		 $this->end_controls_section();
		  $this->start_controls_section(
			'tab_text_content_style',
			[
				'label' => __( 'Text Content Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
			$this->add_control(
			'text_content_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .profile-info ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'text_content_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1000,
					],
					'%' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .profile-info' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		

		$this->add_responsive_control(
			'text_content_alignment',
			[
				'label' => __( 'Alignment', 'tahex_plg' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'tahex_plg' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .profile-info' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_content_typo',
				'label' => __( 'Typo', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .profile-info>p',
			]
		);
		
		$this->add_responsive_control(
			'text_content_position',
			[
				'label' => __( 'Vertical Alignment', 'tahex_plg' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Top', 'tahex_plg' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => __( 'Middle', 'tahex_plg' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => __( 'Bottom', 'tahex_plg' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .profile-info' => 'display:flex; justify-content: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		  $this->start_controls_section(
			'tab_nav_style',
			[
				'label' => __( 'Tab Nav Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'tab_nav_alignment',
			[
				'label' => __( 'Alignment', 'tahex_plg' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'tahex_plg' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default' => 'flex-start',
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills' => 'display:flex; justify-content: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'tab_nav_mt',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1000,
					],
					'%' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'tab_nav_mb',
			[
				'label' => __( 'Margin Bottom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1000,
					],
					'%' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills' => 'margin-Bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		  $this->start_controls_section(
			'tab_nav_anchor_style',
			[
				'label' => __( 'Tab Nav Anchor Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'tab_anchor_w',
			[
				'label' => __( 'Width', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1000,
					],
					'%' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'tab_anchor_h',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1000,
					],
					'%' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'tab_anchor_align',
			[
				'label' => __( 'Alignment', 'tahex_plg' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'tahex_plg' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'tab_anchor_mar',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'tab_anchor_pad',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tab_anchor_typo',
				'label' => __( 'Typo', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} ul.tab-nav.nav.nav-pills li a',
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'tab_anchor_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} ul.tab-nav.nav.nav-pills li a',
			]
		);
		
		$this->add_control(
			'tab_anchor_border_rad',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		
		$this->add_control(
			'tab_anchor_text_color',
			[
				'label' => __( 'Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'tab_anchor_bg_color',
			[
				'label' => __( 'BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'tab_anchor_text_hover_color',
			[
				'label' => __( 'Text Hover Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'tab_anchor_bg_hover_color',
			[
				'label' => __( 'BG Hover Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'tab_anchor_text_active_color',
			[
				'label' => __( 'Text Active Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li.active a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'tab_anchor_bg_active_color',
			[
				'label' => __( 'BG Active Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.tab-nav.nav.nav-pills li.active a' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'tab_anchor_box_shadow',
				'label' => __( 'Box Shadow', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} ul.tab-nav.nav.nav-pills li a ',
			]
		);
		
		$this->end_controls_section();
		


	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {	
	 $tabs = $this -> get_settings_for_display('tabs_items');
	 //$list_icons = $this -> get_settings_for_display('icon_list');
	 $id_int = substr($this->get_id_int(), 0, 3);	 
	?>
.	        <div <?php echo  $this->get_render_attribute_string('tahex-tab-wrapper'); ?>>
                <div class="row site-tab-content tab-content tab-wrapper">	
				
				
                    <?php 
						foreach( $tabs as $index => $item ):
						$tab_count = $index + 1;
						$tab_content_setting_key = $this->get_repeater_setting_key('tab_content','tabs_items', $index);
						$tab_title  = strtolower( preg_replace('/[^a-zA-Z]+/','-',$item['tab_title'] ) );
						$content_id = [strtolower( $tab_title).$id_int.'-'.$tab_count];
						$tab_content = $item['tab_content'];
						$this->add_render_attribute($tab_content_setting_key,[						 
						   'id' => $content_id,
						   'class' =>[ 1 === $tab_count ? 'tab-pane fade in active' : 'tab-pane fade' ],
						   'tabindex' => '0',
						   'aria-controls' => 'tahex-tab-content-' . $id_int . $tab_count,
						]);	
						$this->add_inline_editing_attributes( $tab_content_setting_key, 'advanced' );
					?>
				
				 <div <?php echo $this->get_render_attribute_string($tab_content_setting_key); ?> >		
				     <div class="<?php echo $item['tabs_items_column'];?> <?php if( 'yes' === $item['tabs_items_position_change'] ){ echo 'pull-right'; }?> single-tab-item">						   
							 <!-- lightbox-with-youtube -->							 
							 <?php if('lightbox' === $item['src_type']){?>
						   
							   <div style="background-image:url(<?php echo wp_get_attachment_image_url($item['tab_lightbox_image']['id'],'full');?>);" class="video-poster-bg column-gap">						
									<div class="profile-video-content-wrapper">				
										<div class="profile-video-content">	
											<a class="fancybox-media video" href="<?php echo ($item['tab_lightbox_video_url']);?>"><i class="zmdi zmdi-play"></i></a>
										</div><!-- video-content -->										
									</div><!-- video-content-wrapper -->										
								</div><!-- video-poster -->
								
								
							<!-- single-image-->							
							 <?php  } elseif('image' == $item['src_type']){?>
								
								<div class="single-image column-gap">
								 <img src="<?php echo wp_get_attachment_image_url($item['tab_image']['id'],'full');?>" alt="" />
								</div>

							<!-- slider-->							
							 <?php  } elseif('slider' === $item['src_type']){
								 
								 
								$show_slider = ( in_array( $item['src_type'],['slider','contact'] ) );
								 
								if( $show_slider){
								$tab_slider_id = rand(135,79549);										
								

								 ?>
								 
								 <div class="profile-info wow fadeIn column-gap">
									 <div id="<?php echo $tab_slider_id ?>" class="carousel slide">
										<div class="carousel-inner text-center" role="listbox">	
										
											<?php
											
											   if(empty ( $show_slider ) ){
												   return;
											   }											   
											   $i=0;		
											   $tab_slides_count = count( $item['tab_slider'] );
											   foreach( $item['tab_slider'] as $attachment ):
											   $i++;
											   $image_url = wp_get_attachment_image_url($attachment['id'],'full',$item );
	
											?>
											<div class="item <?php if($i === 1){echo 'active';}?>" >
												<img class="img-responsive" src="<?php echo esc_attr ( $image_url );?>" alt="" />
											</div><!-- item-->
												
											<?php endforeach;?>	
											
										</div><!-- carousel-inner -->
										<ol class="carousel-indicators">
										   <?php 
										     $i=0;
											 for($i=0; $tab_slides_count > $i; $i++){?>
											 
											<li data-target="#<?php echo $tab_slider_id ?>" data-slide-to="<?php echo $i;?>" 
											    class="<?php if($i === 0){echo 'active';}?>">
											</li>
											
											 <?php } ?>
											
										</ol><!-- carousel-indicators -->							
									</div><!-- about-us-carousel -->	
								</div><!-- profile-info-->	
								 <?php } ?>
								
							  <!-- single-youtube-video-->	
							  <?php  } elseif('youtube' === $item['src_type']) { ?>
							 																											
								<div class="ratio ratio-1x1 column-gap">
									<div class="single-video youtube-video-wrapper">
										<div class="single-video-content">	
										  <iframe src="<?php echo ($item['youtube_url']);?>" title="YouTube video" allowfullscreen></iframe>
										</div>											
									</div><!-- single-video-content -->										
								</div><!-- youtube-video-wrapper -->
								
								 <!-- contact-slider-->
							 
							<?php  } elseif('contact' === $item['src_type']) {
                                $show_slider = ( in_array( $item['src_type'],['slider','contact'] ) );
								
								print_r($show_slider);
									 
								if( $show_slider){
								$tab_slider_id = rand(135,79549);	

								?>
							 																											                        <div class="profile-info wow fadeIn column-gap">
									 <div id="<?php echo $tab_slider_id ?>" class="carousel slide">
										<div class="carousel-inner text-center" role="listbox">	
										
											<?php
											
											   if(empty ( $item['tab_slider'] ) ){
												   return;
											   }											   
											   $i=0;		
											   $tab_slides_count = count( $item['tab_slider'] );
											   foreach( $item['tab_slider'] as $attachment ):
											   $i++;
											   $image_url = wp_get_attachment_image_url($attachment['id'],'full',$item );
	
											?>
											<div class="item <?php if($i === 1){echo 'active';}?>" >
												<img class="img-responsive" src="<?php echo esc_attr ( $image_url );?>" alt="" />
											</div><!-- item-->
												
											<?php endforeach;?>	
											
										</div><!-- carousel-inner -->
										<ol class="carousel-indicators">
										   <?php 
										     $i=0;
											 for($i=0; $tab_slides_count > $i; $i++){?>
											 
											<li data-target="#<?php echo $tab_slider_id ?>" data-slide-to="<?php echo $i;?>" 
											    class="<?php if($i === 0){echo 'active';}?>">
											</li>
											
											 <?php } ?>
											
										</ol><!-- carousel-indicators -->							
									</div><!-- about-us-carousel -->	
								</div><!-- profile-info-->	
																							
					 
							    <?php 
							   } 
							} 
							    ?>
						
				
						</div><!-- /.col-md-7 -->
						
						
						<div class="<?php echo $item['tabs_items_column'];?> <?php if( 'yes' === $item['tabs_items_position_change'] ){ echo 'pull-left'; }?>">
						
						  <?php   if('contact' !== $item['src_type']):?>
							    <div class="text-content profile-info wow fadeIn column-gap ">		
									<h2 class="profile-info-heading">
										<?php echo $item['tab_sub_title']; ?>
									</h2>																		
									<?php if('yes' === $item['show_subtitle_bottom_border']){?>
									 <span class="profile-border"></span>
									<?php }?>
									<p class="profile-info-para"> 																		
										<?php 										
											if('contact' !== $item['src_type']){
												echo $this->parse_text_editor ( $item['tab_content'] );
											}
										?>									
									</p>											
								</div><!-- profile-info -->	
								
							<?php endif;?>	
							
								
						    </div><!-- /.col-md-12 -->	

						    <?php if('contact' === $item['src_type']):?>									 
								<div class="col-md-5">
									<h1 class="message-info-heading"> <?php echo $item['tab_sub_title']; ?> </h1>
								</div><!--/.col-md-5 -->
								<div class="col-md-7">
									<div class="contact-form-wrapper">
										 <?php echo $this->parse_text_editor ( $item['tab_content'] ); ?>
									</div><!--contact-form-wrapper -->	
							    </div><!--/.col-md-7 -->	
										 
                              <?php endif;?>
							  
							  <?php if('gmap' === $item['src_type']):?>	
							    <div class="col-md-12">
									<div class="contact-form-wrapper">
										 <?php echo $this->parse_text_editor ( $item['tab_content'] ); ?>
									</div><!--contact-form-wrapper -->	
							    </div><!--/.col-md-7 -->	
								<div class="col-md-5">
									<h1 class="message-info-heading"> <?php echo $item['tab_sub_title']; ?> </h1>
								</div><!--/.col-md-5 -->
								<div class="col-md-4">	
									<div class="office-location-content">	

                                        <?php 
												$this->add_render_attribute( 'icon_list', 'class', 'tahex-icon-list' );
												$this->add_render_attribute( 'list_item', 'class', 'tahex-icon-list-item' );
											?>
									
										<ul class="office-address list-unstyled inline-block" 
										     <?php echo $this->get_render_attribute_string('icon_list');?>>

                                           <?php 
										   
										    $repeater_setting_key = $this->get_repeater_setting_key( 'text', 'icon_list', $item);
										   
										    $this->add_render_attribute( $repeater_setting_key , 'class', 'icon-list-text');
										    $this->add_inline_editing_attributes( $repeater_setting_key );
										  ?>	
										  
											<li  data-toggle="tooltip" data-placement="left" title="location" <?php echo $this->get_render_attribute_string( 'list_item' ); ?>>
													<?php
														if ( $is_new ) {
															Icons_Manager::render_icon( $icon['selected_icon'], ['aria-hidden' => 'true' ] );
														} else { ?>
														<i class="<?php echo esc_attr( $icon['selected_icon']['value'] ); ?>" aria-hidden="true"></i>
													<?php } ?>
												<span><?php echo $icon['text']?></span>												
											</li>
											
										</ul><!-- office-address -->														
								    </div><!-- office-location-content -->
							    </div><!--/.col-md-4 -->
								<div class="col-md-3">	
									<h4 class="social-media-heading"> Find us in social media  </h4>
									<ul class="office-social-media list-unstyled list-inline">
										<li data-toggle="tooltip" title="twitter"><a href="www.twitter.com"><i class="zmdi zmdi-twitter"></i></a></li>
										<li data-toggle="tooltip" title="linkedin"><a href="www.linkedin.com"><i class="zmdi zmdi-linkedin" title="linkedin"></i></a></li>
										<li data-toggle="tooltip" title="pinterest"><a href="www.pinterest.com"><i class="zmdi zmdi-pinterest" title="pinterest"></i></a></li>
										<li data-toggle="tooltip" title="google-plus"><a href="www.google-plus.com"><i class="zmdi zmdi-google-plus" title="google-plus"></i></a></li>
										<li data-toggle="tooltip" title="dribbble"><a href="www.dribbble.com"><i class="zmdi zmdi-dribbble" title="dribbble"></i></a></li>
									</ul><!-- office-social-media -->		
							</div><!--/.col-md-3-->			 
										 
                              <?php endif;?>  
							  

					</div><!--single-tab-wrapper-->									
										
					
                  <?php endforeach;?>
				  
				  	<?php if($tab_count > 1){?>

						<div class="col-md-12">	                     		
							<ul class="tab-nav nav nav-pills">						
							  <?php 
								 foreach ( $tabs as $index => $item ): 
								 $tab_count = $index + 1;
								 $tab_title_setting_key = $this->get_repeater_setting_key('tab_title','tabs_items', $index);
								 $tab_title  = strtolower(preg_replace('/[^a-zA-Z]+/','-',$item['tab_title']));
								 $tab_anchor = '#'.$tab_title.$id_int.'-'.$tab_count;
								 $this->add_render_attribute($tab_title_setting_key,[						 
								   'class' =>[ 1 === $tab_count ? 'tahex-tab-title active' : 'tahex-tab-title' ],
								   'tabindex' => 1 === $tab_count ? '0' : '-1',
								   'aria-controls' => 'tahex-tab-content-' . $id_int . $tab_count,
								   
								 ]);
							  
							  ?>
							
								<li <?php echo $this->get_render_attribute_string($tab_title_setting_key);?>>
								   <a data-toggle="pill" href="<?php echo $tab_anchor;?>">
									 <?php echo $item['tab_title'] ;?>
								   </a>
								</li>
								
							  <?php endforeach; ?>						
							</ul><!-- tab-nav-wrapper -->					
						</div><!-- /.col-md-12 -->

					<?php }?>	
						
				</div><!-- tab-wrapper -->
            </div>

	<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

