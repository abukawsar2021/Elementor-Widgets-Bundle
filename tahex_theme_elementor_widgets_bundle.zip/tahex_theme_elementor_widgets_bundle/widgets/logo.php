<?php
namespace TahexPlugin\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\ Utils;
use Elementor\ Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Logo extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'logo';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Site Logo', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-site-logo';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
	$this->start_controls_section(
			'logo_settings',
			[
				'label' => __( 'Logo Settings', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		
	$this->add_control(
			'logo_show',
			[
				'label' => __( 'Show / Hide', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		
		$this->add_control(
			'logo_img',
			[
				'label' => __( 'Uploa Logo Image', 'tahex_plg' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		
		
		$this->add_responsive_control(
			'logo_width',
			[
				'label' => __( 'Width', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .logo' => 'width: {{SIZE}}{{UNIT}}',
				],
			]
		);
		
		
		
		$this->add_responsive_control(
			'logo_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .logo' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		
		$this->add_responsive_control(
			'logo_margin_l',
			[
				'label' => __( 'Margin Left', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .logo' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		$this->add_responsive_control(
			'logo_margin_r',
			[
				'label' => __( 'Margin Right', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .logo' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'logo_margin_t',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .logo' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
			
		$this->add_responsive_control(
			'logo_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' =>  Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .logo' => 'padding: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->end_controls_section();	
		
		$this->start_controls_section(
			'logo_style',
			[
				'label' => __( 'Logo Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .logo',
			]
		);
		
		$this->end_controls_section();	
		
		
		/* $this->add_control(
			'tahex_menu',
			[
				'label' => __( 'Select Menu', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => navmenu_navbar_menu_choices(),
				'default' => '',
			]
		);
		
		
		$this->add_control(
			'menu_type',
			[
				'label' => __( 'Drop Down Type', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::SELECT,				
				'options' => [
					'left'  => __( 'From Left', 'tahex_plg' ),
					'rigth' => __( 'From Right', 'tahex_plg' ),
				],
				'default' => 'left',
			]
		);
		
		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Parent Menu Alignment', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .menu-wrapper' => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Child Menu Alignment', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .menu-default>ul>li>ul' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'desktop_menu',
			[
				'label' => __( 'Default Menu', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
					'inline-block' => __( 'Show', 'tahex_plg' ),
					'none' => __( 'Hide', 'tahex_plg' ),					
				],
				'default' => 'inline-block',
				'selectors' => [
					'{{WRAPPER}} .menu-default' => 'display: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'mobile_menu',
			[
				'label' => __( 'Mobile Menu', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
					'inline-block' => __( 'Show', 'tahex_plg' ),
					'none' => __( 'Hide', 'tahex_plg' ),					
				],
				'selectors' => [
					'{{WRAPPER}} .menu-mobile' => 'display: {{VALUE}};',
				],
			]
		);	
	$this->end_controls_section();	
	
	$this->start_controls_section(
			'menu_section',
			[
				'label' => __( 'Default Menu Settings(parent)', 'tahex_plg' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		
	
	$this->add_responsive_control(
			'd_menu_list_margin',
			[
				'label' => __( 'Menu List Margin', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .menu-default>div.menu-list>a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'd_menu_list_padding',
			[
				'label' => __( 'Menu List Padding', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .menu-default>div.menu-list>a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
	$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'd_menu_item_typography',
				'label' => __( 'Menu List Item Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .menu-default>div.menu-list>a',
			]
		);

		$this->add_control(
			'd_menu_list_item_color',
			[
				'label' => __( 'Menu List Item  Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .menu-default>div.menu-list>a' => 'color: {{VALUE}}',
				],
			]
		);
		
	$this->add_control(
			'd_menu_list_item_color_hover',
			[
				'label' => __( 'Menu List Item  Color On Hover', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .menu-default>div.menu-list>a:hover' => 'color: {{VALUE}}',
				],
			]
		);
	
	
	
	
	
	$this->end_controls_section();
	
	
	$this->start_controls_section(
			'pointer_settings',
			[
				'label' => __( 'Pointer Settings', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
	
	$this->add_control(
			'show_pointer',
			[
				'label' => __( 'Show / Hide', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .header-area.absolute .down-arrow',
					'condition' => [
					'show_pointer' => 'yes',
				],
			]
		);

 
$this->add_control(
			'pointer_width_height',
			[
				'label' => __( 'Width', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

	$this->add_control(
			'pointer_border_radius',
			[
				'label' => __( 'Border Radius', 'plugin-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
	
	$this->add_control(
			'pointer_margin_top',
			[
				'label' => __( 'Margin Top', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'top: {{TOP}}{{UNIT}};',
				],
			]
		);
	
	
	
	$this->add_control(
			'pointer_arrow_width_height',
			[
				'label' => __( 'Arrow Font Size', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
	
	
	
		

		$this->end_controls_section();
	
	
	$this->start_controls_section(
			'mobile_menu_section',
			[
				'label' => __( 'Mobile Menu Settings( Dropdown )', 'tahex_plg' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
	
	
	$this->add_responsive_control(
			'mobile_menu_top_margin',
			[
				'label' => __( 'Mobile Menu Wrapper Top Margin', 'tahex_plg' ),
				'type' =>  \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .menu-mobile' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
	
		
		
		$this->add_responsive_control(
			'mobile_menu_align',
			[
				'label' => __( 'Mobile Menu Alignment', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .menu-mobile>ul>li' => 'text-align: {{VALUE}}',
				],
			]
		);
		 */
        
		
	
	$this->end_controls_section();
	

	
	
	}

	
	
	
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
    $settings = $this->get_settings_for_display();?>
	
		<!-- CUSTOM LOGO -->
     <div class="custom-logo">
	    <?php if($settings['logo_show']): ?>
		
	    <a class="logo section-scroll" href="<?php echo esc_url( home_url('/') );?>index.html#home">
		   <img  class="img-responsive" src="<?php echo esc_url( wp_get_attachment_image_url( $settings['logo_img']['id'], 'full' ) );?> "/>
		</a>
		
		 <?php endif;?>
	 </div>
	     <!-- END-CUSTOM LOGO -->
	
	
	 
	<?php }

}
