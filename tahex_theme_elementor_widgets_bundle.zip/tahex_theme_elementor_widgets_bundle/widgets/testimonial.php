<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Testimonial extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-testimonila';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Testimonila Slider', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'testimonial_section_content',
			[
				'label' => __( 'Testimonial  Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'testimonial_icon',
			[
				'label' => __( 'Testimonial Icon', 'text-domain' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'solid',
				],
			]
		);
		

		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'testimonial_title', [
				'label' => __( 'Testimonial Title', 'tahex_plg' ),
				'type' =>Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'testimonial_content', [
				'label' => __( 'Testimonial Content', 'tahex_plg' ),
				'type' => Controls_Manager::TEXTAREA,
				'show_label' => true,
			]
		);

		$repeater->add_control(
			'testimonial_avatar',
			[
				'label' => __( 'Testimonial Avatar', 'tahex_plg' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'testimonial_list',
			[
				'label' => __( 'Testimonial List', 'tahex_plg' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'testimonial_title' => __( 'Title #1', 'tahex_plg' ),
						'testimonial_content' => __( 'Item content. Click the edit button to change this text.', 'tahex_plg' ),
					],
					[
						'testimonial_title' => __( 'Title #2', 'tahex_plg' ),
						'testimonial_content' => __( 'Item content. Click the edit button to change this text.', 'tahex_plg' ),
					],
					[
						'testimonial_title' => __( 'Title #3', 'tahex_plg' ),
						'testimonial_content' => __( 'Item content. Click the edit button to change this text.', 'tahex_plg' ),
					],
				],
			]
		);
		

		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_navigation_settings',
			[
				'label' => __( 'Testimonial  Naviation Settings', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'dots',
			[
				'label' => __( 'Show Dots', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'nav',
			[
				'label' => __( 'Show Nav', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'loop',
			[
				'label' => __( 'Enable Loop or not', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Enable Autoplay or not', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		
		
		$this->add_control(
			'speed',
			[
				'label' => __( 'Animation Duration', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 2000,
				'min' => 100,
				'step' => 100,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
			
		);
		
		$this->end_controls_section();
	
	$this->start_controls_section(
			'testimonial_navigation_settings',
			[
				'label' => __( 'Testimonial  Naviation Settings', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'dots',
			[
				'label' => __( 'Show Dots', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'nav',
			[
				'label' => __( 'Show Nav', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'loop',
			[
				'label' => __( 'Enable Loop or not', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Enable Autoplay or not', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		
		
		$this->add_control(
			'speed',
			[
				'label' => __( 'Animation Duration', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 2000,
				'min' => 100,
				'step' => 100,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
			
		);
		
		$this->end_controls_section();

		
		$this->start_controls_section(
			'testimonial_style',
			[
				'label' => __( 'Testimonial Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
       $this->add_control(
			'testi_area_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .clients-area' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'testi_area_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .clients-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_icon_style',
			[
				'label' => __( 'Icon Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
			'testi_area_icon_size',
			[
				'label' => __( 'Icon Size', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 6,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clients-area .quote-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'testi_area_icon_rotate',
			[
				'label' => __( 'Rotate', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'deg' ],
				'default' => [
					'size' => 0,
					'unit' => 'deg',
				],
				'tablet_default' => [
					'unit' => 'deg',
				],
				'mobile_default' => [
					'unit' => 'deg',
				],
				'selectors' => [
					'{{WRAPPER}} .clients-area .quote-icon i' => 'transform: rotate({{SIZE}}{{UNIT}});',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'testi_area_icon_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .clients-area .quote-icon i',
			]
		);

        $this->add_control(
			'testi_area_icon_border_rad',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .clients-area .quote-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'testi_area_icon_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .clients-area .quote-icon i' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'testi_area_icon_color',
			[
				'label' => __( 'Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .clients-area .quote-icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'testi_area_icon_pad',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .clients-area .quote-icon i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_caro_wrap_style',
			[
				'label' => __( 'Testimonial Wrapper', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'testi_area_caro_box_pad',
			[
				'label' => __( 'Testimonial Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .carousel-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'testi_area_caro_box_content_typography',
				'label' => __( 'Testimonial Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .carousel-box p',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_caro_wrap_avatar_style',
			[
				'label' => __( 'Testimonial Avatar Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'testi_area_caro_box_avatar',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .carousel-box figure.client-avatar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_caro_wrap_avatar_img_style',
			[
				'label' => __( 'Testimonial Avatar Image Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'testi_area_caro_box_avatar_img_w_h',
			[
				'label' => __( 'Width and Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .carousel-box figure.client-avatar>img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'testi_area_caro_box_avatar_img_rotate',
			[
				'label' => __( 'Rotate', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'deg' ],
				'default' => [
					'size' => 0,
					'unit' => 'deg',
				],
				'tablet_default' => [
					'unit' => 'deg',
				],
				'mobile_default' => [
					'unit' => 'deg',
				],
				'selectors' => [
					'{{WRAPPER}} .carousel-box figure.client-avatar>img' => 'transform: rotate({{SIZE}}{{UNIT}});',
				],
			]
		);
		
		$this->add_control(
			'testi_area_caro_box_avatar_img_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .carousel-box figure.client-avatar>img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'testi_area_caro_box_avatar_img_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .carousel-box figure.client-avatar>img',
			]
		);

        $this->add_control(
			'testi_area_caro_box_avatar_img_border_rad',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .carousel-box figure.client-avatar>img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_client_title_style',
			[
				'label' => __( 'Testimonial Title Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'testimonial_client_title_typography',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .carousel-box h3.client-title',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonial_dots_style',
			[
				'label' => __( 'Dots Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'dots_width',
			[
				'label' => __( 'Dots Width', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dots' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		 $this->add_control(
			'dots_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'dot_width_height',
			[
				'label' => __( 'Dot Width & Height', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'testi_dots_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .clients-carousel .owl-dot',
			]
		);

        $this->add_control(
			'testi_dots_border_rad',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'testi_dots_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dot' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'testi_dots_bg_color_active',
			[
				'label' => __( 'BG Color on Active', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dot.active' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'testi_dots_bg_color_active_border',
				'label' => __( 'Border on Active', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .clients-carousel .owl-dot.active',
			]
		);

        $this->add_control(
			'testi_dots_bg_color_active_border_rad',
			[
				'label' => __( 'Border Radius on Active', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'testi_dots_bg_color_on_hover',
			[
				'label' => __( 'Hover BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .clients-carousel .owl-dot.hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->end_controls_section();
		
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();	
	
	   if('yes' === $settings['dots']){
		   $dots = 'true';
	   }else{
		   $dots = 'false';
	   }
	   
	   if('yes' === $settings['nav']){
		   $nav = 'true';
	   }else{
		   $nav = 'false';
	   }
	   
		if('yes' === $settings['loop']){
			   $loop = 'true';
		   }else{
			   $loop = 'false';
		}
		
		if('yes' === $settings['autoplay']){
			   $autoplay = 'true';
		   }else{
			   $autoplay = 'false';
		}
		
		if('yes' === $settings['speed']){
			   $speed = 'true';
		   }else{
			   $speed = 'false';
		}
		
	
	?>
	
	<script type="text/javascript">
	
			(function($) {
			"use strict";
			/*-------------------CLIENTS-SLIDER----------------------*/
			
			jQuery(document).ready(function($){
				var clientsSlider = $('.clients-carousel');		
				clientsSlider.owlCarousel({
					items: 1,			
					loop: <?php echo $loop; ?>,
					animateOut:'fadeOut',
					animateIn:'fadeIn',
					margin: 30,					
					autoplay:<?php echo $autoplay; ?>,					
					<?php if($settings['autoplay'] == 'yes'){ ?>
					smartSpeed: <?php echo $settings['speed']; ?>,
					<?php } ?>					
					dots: <?php echo $dots; ?>,
					mouseDrag:false,
					nav: <?php echo $nav; ?>,
					navText: ["<i class='fas fa-chevron-left'></i>",
							"<i class='fas fa-chevron-right'></i>"
						],

				  });
			  });
			
		}(jQuery));
	
	</script>
	
  <div class="clients-area carousel-content">
   	<div class="quote-icon"><i class="<?php echo $settings['testimonial_icon']['value']?>"></i></div>	
		<div class="clients-carousel owl-carousel">		
			<?php foreach( $settings['testimonial_list'] as $client ):?>			
				<div class="carousel-box">
					<div class="single-carousel-content">
					 <?php echo ( wpautop($client['testimonial_content']) );?>
					</div><!--single-carousel-content-->			
					<figure class="client-avatar"><img src="<?php echo ( wp_get_attachment_image_url($client['testimonial_avatar']['id'],'full') );?>" alt="">
						 <figcaption>
						 <h3 class="client-title"> - <?php echo($client['testimonial_title']);?> - </h3></figcaption>									
					</figure>				 
				</div><!--carousel-box-->												
			<?php endforeach;?>						
		</div><!--clients-carousel-->		
	</div>	<!--clients-area-->					
	<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

