(function($) {
    "use strict";

	jQuery(document).ready(function($){
		   /*-------------------------------- FANCYBOX ----------------------------*/
		
		var fancyboxImage = $('.fancybox').attr('rel', 'gallery');
		var fancyboxVideo = $('.fancybox-media');
		
		fancyboxImage.fancybox({
			'speedIn': 600,
			'speedOut': 200,
			'transitionIn': 'elastic',
			'transitionOut': 'elastic',

		});

		fancyboxVideo.fancybox({
			'speedIn': 600,
			'speedOut': 200,
			'transitionIn': 'elastic',
			'transitionOut': 'elastic',
			'autoScale': true,
			'titleShow': true,
			'type': 'iframe'
		});

		
	});
   

}(jQuery));