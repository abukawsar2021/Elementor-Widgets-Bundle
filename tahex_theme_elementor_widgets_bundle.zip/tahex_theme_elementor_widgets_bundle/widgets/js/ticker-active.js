(function($) {
    "use strict";
	
				
     /*------------------------------------------TICKER------------------------------*/
	 
	  var sloganContent = $('.single-slogan-content');	  
	  sloganContent.list_ticker({
		  speed:8000,
          effect:'fade'
	   });
	   

}(jQuery));