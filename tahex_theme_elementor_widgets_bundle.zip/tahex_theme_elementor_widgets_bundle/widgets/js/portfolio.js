(function($) {
    "use strict";


     /*---------------------------- ISOTOPE SETTING ---------------------------------*/

		var $container = $('.project-items');		
			$container.imagesLoaded(function(){
			$container.isotope();

		});
 

	

    /*---------------------------- WORK-FILTER -----------------------------------*/

	 var workFilterMenuAnchor = $('.work-menu li a'); 	 
	 var workGridItem = '.element-item'; 	 
	 workFilterMenuAnchor.on('click', function() {		 
     workFilterMenuAnchor.removeClass('selected');        
	 $(this).addClass('selected');
	 
	 var selector = $(this).attr('data-filter');	
	 $container.isotope({
		 itemSelector: workGridItem,
		 filter: selector,
		 animationOptions: {
			 duration: 5000,
			 easing: 'easeInOutExpo',
			 queue: false
            }
        });
        return false;
		
    });


	

}(jQuery));