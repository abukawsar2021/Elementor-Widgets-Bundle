(function($) {
    "use strict";

			  
	/*------------------------------- PRICING-TABLE-ACTIVE ----------------------------*/
	
	var pricingTableHover = $('.single-pricing-table-wrapper');	
	pricingTableHover.hover(function(){
		pricingTableHover.removeClass('active');
		$(this).addClass('active');

	});

	

}(jQuery));