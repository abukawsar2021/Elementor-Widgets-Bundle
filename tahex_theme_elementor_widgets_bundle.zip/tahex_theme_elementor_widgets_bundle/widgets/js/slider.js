(function($) {
    "use strict";
			
	/*-------------------HOME-SLIDER----------------------*/
	
	var homeSlider = $('.home-sliders');
	homeSlider.owlCarousel({
        items: 1,
        loop: true,
        smartSpeed: 1000,
        autoplay: true,
		animateIn: 'fadeIn',
		animateOut: 'fadeOut',
		mouseDrag:false,
        dots: true,
        nav: true,
		navText: ["<i class='zmdi zmdi-chevron-left'></i>",
            "<i class='zmdi zmdi-chevron-right'></i>"
        ]
    });	
	
}(jQuery));