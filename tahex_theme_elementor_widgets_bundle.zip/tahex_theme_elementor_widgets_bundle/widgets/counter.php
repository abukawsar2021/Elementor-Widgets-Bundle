<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Counter extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-counter';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Counter', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-counter-circle';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'counter_section_content',
			[
				'label' => __( 'Counter Item Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		
		$this->add_control(
			'counter_num_start',
			[
				'label' => __( 'Starting Number', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,				
				'default' => 0,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		
		
		
		$this->add_control(
			'counter_num_end',
			[
				'label' => __( 'Ending Number ', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 100,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		
		$this->add_control(
			'counter_title',
			[
				'label' => __( 'Title', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
			]
		);
		
		
		$this->add_control(
			'counter_anim_dur',
			[
				'label' => __( 'Animation Duration', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 2000,
				'min' => 100,
				'step' => 100,
				
			]
		);
		
		
		$this->add_control(
			'counter_item_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-counter-item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'counter_item_style',
			[
				'label' => __( 'Counter Item Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'counter_item_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-counter-item',
			]
		);
		
		
		
		$this->add_control(
			'counter_item_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-counter-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'counter_item_border_radius',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-counter-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'single_counter_style',
			[
				'label' => __( 'Single Counter Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		
		$this->add_control(
			'single_counter_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-counter' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'single_counter_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-counter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'single_counter_border_rad',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-counter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'counter_title_style',
			[
				'label' => __( 'Counter Title Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'counter_title_typo',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-counter h5',
			]
		);
		
		$this->add_control(
			'counter_title_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-counter h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'counter_num_style',
			[
				'label' => __( 'Counter Number Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'counter_num_typo',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-counter .countnum',
			]
		);
		
		
		
		$this->end_controls_section();
		
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();	
	$dynamic_id = rand(14525,258741);	
	?>
	            <script type="text/javascript">
  
					 jQuery(document).ready(function($){
						 /*------------------------------------------COUNTER------------------------------*/
					 
						var countNum = $('#count-test-<?php echo $dynamic_id; ?>');
						 
						countNum.jQuerySimpleCounter({
							start: <?php echo ( $settings['counter_num_start'] );?>,
							end: <?php echo ( $settings['counter_num_end'] );?>,
							easing: 'swing',
							duration: <?php echo ( $settings['counter_anim_dur'] );?> 
						});
						 
					 });

				</script>	
				<div class="single-counter-item">
					<div class="single-counter">
						<div class="countnum" id="count-test-<?php echo $dynamic_id; ?>"></div>
						<h5> <?php echo $settings['counter_title'];?> </h5>
					</div><!-- single-counter -->		
				</div><!-- single-counter-item -->										
        
		<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

