<?php
namespace TahexPlugin\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Menu extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'menu';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Menu', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'fa fa-th-large';
	}
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
	$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Menu Settings', 'tahex_plg' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		
		$this->add_control(
			'tahex_menu',
			[
				'label' => __( 'Select Menu', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => navmenu_navbar_menu_choices(),
				'default' => '',
			]
		);
		
		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Parent Menu Alignment', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} #custom-menubar.menubar-fixed-top .nav main-menu menu-right menu-right-xs menu' => 'text-align: {{VALUE}}',
				],
			]
		);

		
		
		$this->add_responsive_control(
			'desktop_menu',
			[
				'label' => __( 'Default Menu', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
					'inline-block' => __( 'Show', 'tahex_plg' ),
					'none' => __( 'Hide', 'tahex_plg' ),					
				],
				'default' => 'inline-block',
				'selectors' => [
					'{{WRAPPER}} #custom-menubar.menubar-fixed-top' => 'display: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'mobile_menu',
			[
				'label' => __( 'Mobile Menu', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
					'inline-block' => __( 'Show', 'tahex_plg' ),
					'none' => __( 'Hide', 'tahex_plg' ),					
				],
				'selectors' => [
					'{{WRAPPER}} .mobile-menu' => 'display: {{VALUE}};',
				],
			]
		);	
	$this->end_controls_section();	
	
	$this->start_controls_section(
			'menu_section',
			[
				'label' => __( 'Menu Settings(parent)', 'tahex_plg' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'menu_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #custom-menubar.menubar-fixed-top' => 'background-color: {{VALUE}}',
				],
			]
		);

		
		
		$this->add_responsive_control(
			'menu_left_margin',
			[
				'label' => __( 'Margin Left', 'tahex_plg' ),
				'type' =>  \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} #custom-menubar ul.main-menu' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'd_menu_top_margin',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' =>  \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} #custom-menubar.menubar-fixed-top' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'd_menu_top_padding',
			[
				'label' => __( 'Padding Top', 'tahex_plg' ),
				'type' =>  \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} #custom-menubar.menubar-fixed-top' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'd_menu_top_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' =>  \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} #custom-menubar.menubar-fixed-top' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
	
	$this->add_responsive_control(
			'd_menu_list_margin',
			[
				'label' => __( 'Menu List Margin', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} #custom-menubar ul.main-menu li>a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'd_menu_list_padding',
			[
				'label' => __( 'Menu List Padding', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} #custom-menubar ul.main-menu li>a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
	$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'd_menu_item_typography',
				'label' => __( 'Menu List Item Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} #custom-menubar ul.main-menu li>a',
			]
		);

		$this->add_control(
			'd_menu_list_item_color',
			[
				'label' => __( 'Menu List Item  Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #custom-menubar ul.main-menu li>a' => 'color: {{VALUE}}',
				],
			]
		);
		
	$this->add_control(
			'd_menu_list_item_color_hover',
			[
				'label' => __( 'Menu List Item  Color On Hover', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #custom-menubar ul.main-menu li>a:hover' => 'color: {{VALUE}}',
				],
			]
		);
	
	
	
	
	
	$this->end_controls_section();
	
	/* 
	$this->start_controls_section(
			'pointer_settings',
			[
				'label' => __( 'Pointer Settings', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
	
	$this->add_control(
			'show_pointer',
			[
				'label' => __( 'Show / Hide', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'tahex_plg' ),
				'label_off' => __( 'Hide', 'tahex_plg' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
 */

/* $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .header-area.absolute .down-arrow',
					'condition' => [
					'show_pointer' => 'yes',
				],
			]
		);

 
$this->add_control(
			'pointer_width_height',
			[
				'label' => __( 'Width', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		); */

	/* $this->add_control(
			'pointer_border_radius',
			[
				'label' => __( 'Border Radius', 'plugin-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
	
	$this->add_control(
			'pointer_margin_top',
			[
				'label' => __( 'Margin Top', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'top: {{TOP}}{{UNIT}};',
				],
			]
		); */
	
	
	
	/* $this->add_control(
			'pointer_arrow_width_height',
			[
				'label' => __( 'Arrow Font Size', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .header-area.absolute .down-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
	
	 */
	
		

		$this->end_controls_section();
	
	
	$this->start_controls_section(
			'mobile_menu_section',
			[
				'label' => __( 'Mobile Menu Settings( Dropdown )', 'tahex_plg' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
	
	
	$this->add_responsive_control(
			'mobile_menu_top_margin',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' =>  \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],	
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mobile-menu' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
	
		
		
		$this->add_responsive_control(
			'mobile_menu_align',
			[
				'label' => __( 'Alignment', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .mobile-menu>ul>li' => 'text-align: {{VALUE}}',
				],
			]
		);
		
        
		
	
	$this->end_controls_section();
	

	
	
	}

	
	
	
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
    $settings = $this->get_settings_for_display();?>
	
	<script type="text/javascript">
				(function($) {
				"use strict";

				/*------------------------------- 
				MENU-FIXED-TOP-ON-SCROLL 
				----------------------------*/
				
				var windows = $(window);
				var customMenubarOffsetTop = $("#custom-menubar");
				var customMenubarFixedTop = $(".menubar-fixed-top");
				
					windows.on('scroll',function() {
					if (customMenubarOffsetTop.offset().top > 50) {
							customMenubarFixedTop.addClass("top-nav-collapse");
						} else {
							customMenubarFixedTop.removeClass("top-nav-collapse");
						}
					});
					
					
					
				/*------------------------------- 
				MENU-COLLASP-ON-CLICK 
				----------------------------*/
				
				var mainMenuCollasp = $(".mymenu");		
				mainMenuCollasp.find("li").on('click', "a", function (event) {
					$('.navbar-collapse.in').collapse('hide');
				});
			}(jQuery));

	</script>
	
	
		<!-- START-HEADER -->
		
	 <div class="menu-area">    
		<!-- Navigation -->
		<nav id="custom-menubar" class="navbar menubar-fixed-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".mymenu">
					  <i class="zmdi zmdi-sort-amount-desc zmdi-hc-2x"></i>
					</button>				  
				</div><!-- /.navbar-header --> 
				
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="mymenu mobile-menu collapse navbar-collapse ">
					
					<?php 
					
					wp_nav_menu(array(					
					 'main-menu'=> $settings['tahex_menu'],
					  'items_wrap'  => '<ul id="%1$s" class="nav main-menu menu-right menu-right-xs %2$s">%3$s</ul>'
					));
					
					?>

				</div><!-- /.navbar-collapse -->           			
			 </div><!-- /.container -->
		</nav><!-- nav -->
		
	<!--header-area-->	
		
		
		
	<!-- END-HEADER -->
	
	
	 
	<?php }

}
