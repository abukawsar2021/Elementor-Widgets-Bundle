<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Brand extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-brand';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Brand Logo', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-logo';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'brand_section_content',
			[
				'label' => __( 'Brand Logo Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'brand_images',
			[
				'label' => __( 'Brand Images', 'tahex_plg' ),
				'type' => Controls_Manager::GALLERY,
				'default' => [],
			]
		);
		
		
		$this->add_control(
			'brand_dots',
			[
				'label' => __( 'Show Dots', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'your-plugin' ),
				'label_off' => __( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		
		$this->add_control(
			'brand_nav',
			[
				'label' => __( 'Show Nav', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'your-plugin' ),
				'label_off' => __( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'brand_style',
			[
				'label' => __( 'Brand Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'brand_wrapper_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-brand-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        
		
		$this->add_control(
			'brand_wrapper_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-brand-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->add_control(
			'brand_wrapper_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-brand-wrapper' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'single_brand_item_style',
			[
				'label' => __( 'Single Brand Item Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'single_brand_item_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-brand-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'single_brand_item_h',
			[
				'label' => __( 'Height', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .single-brand-item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		
		$this->add_control(
			'single_brand_item_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-brand-item' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'single_brand_item_border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-brand-item',
			]
		);
		
		
		$this->add_control(
			'single_brand_item_border_radius',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-brand-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->end_controls_section();
		
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();?>
	
	
	   <?php
	   
	    if($settings['brand_dots'] == 'yes' ){
			 $brand_dots = 'true';
		 }else{
			 $brand_dots = 'false'; 
		 }
		 
		  if( $settings['brand_nav'] == 'yes' ){
			 $brand_nav = 'true';
		 }else{
			 $brand_nav = 'false'; 
		 }

	   ?>
	
	
	
	<script type="text/javascript">
	
		(function($) {
		"use strict";
		
		/*----------------------------- BRAND-SLIDER / PATNERS-SLIDER ----------------------------*/
		
		jQuery(document).ready(function($){
			var brandSlider = $('.brand-carousel');		
			brandSlider.owlCarousel({
				items:3,
				loop: true,
				margin:30,
				smartSpeed: 800,
				autoplay: true,
				animation: true,
				responsiveClass: true,
				dots: false,
				nav: <?php echo $brand_nav ;?>,
				navText: ["<i class='zmdi zmdi-chevron-left'></i>",
							"<i class='zmdi zmdi-chevron-right'></i>"
						],
				responsive: {
					0: {
						items: 1,
						nav: false
					},
					480: {
						items: 2,
						nav: false
					},
					750: {
						items:3,
						nav: false
					},
					970: {
						items:5,
						nav: false
					},
					1170: {
						items:6,
						nav: false
					}
					
				}

			});			
		});

	}(jQuery));

	</script>
    
      <div class="brand-wrapper brand-carousel owl-carousel">
	   
	        <?php foreach($settings['brand_images'] as $brandImage):?>
	  
			<div class="single-brand-item wow fadeIn">
				<a href="#"><img src="<?php echo ( $brandImage['url'] );?>" alt=""></a>
			</div><!-- single-brand-item -->
			
			<?php endforeach;?>
			
			<?php if($settings['brand_nav'] ==  'yes'){?>
			
				<style type="text/css">
				.brand-wrapper.brand-carousel.owl-carousel .owl-nav{
					 display: block;
					 opacity: 1;	
					}
				</style>
				
			<?php } ?>
			

		</div><!--single-brand-wrapper -->



			   
        
	<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

