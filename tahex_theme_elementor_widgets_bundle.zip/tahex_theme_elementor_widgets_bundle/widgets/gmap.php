<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Plugin;
use Elementor\Settings;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class Tahex_Google_Map extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-google-map';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Google Map', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-google-maps';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	/**
	 * @since 1.0.0
	 * @access protected
	 */
	
	
	protected function register_controls() {
		$this->start_controls_section(
			'section_map_my',
			[
				'label' => __( 'Google Map', 'tahex_plg' ),
			]
		);

		if ( Plugin::$instance->editor->is_edit_mode() ) {
			$map_api_key = get_option( 'gmap_api_key' );
			
			

			if ( ! $map_api_key ) {
				$this->add_control(
					'api_key_notification_see',
					[
						'type' => Controls_Manager::RAW_HTML,
						'raw' => sprintf(
							__( 'Set your Google Maps API Key in Elementor\'s <a href="%1$s" target="_blank">Integrations Settings</a> page. Create your key <a href="%2$s" target="_blank">here.', 'elementor' ),
							Settings::get_url() . '#tab-integrations',
							'https://developers.google.com/maps/documentation/embed/get-api-key'
						),
						'content_id' => '',
					]
				);
			}
		}
		$this->add_control(
			'address',
			[
				'label' => __( 'Location', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' =>__( 'Uttara, Dhaka, Bangladesh', 'tahex_plg' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'content',
			[
				'label' => __( 'Content', 'tahex_plg' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => $default_address_have,
				'default' =>__( 'Address: Dhaka-1230,Bangladesh Contact:0088 01234 567890', 'tahex_plg' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'latitude',
			[
				'label' => __( 'Latitude', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => 23.777176,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);
		
		
		$this->add_control(
			'longitude',
			[
				'label' => __( 'Longitude', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => 90.399452,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);
		
		
		$this->add_control(
			'mapTypeId',
			[
				'label' => __( 'Map Type Id', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'shadeOfGrey',
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);


		$this->add_control(
			'zoom',
			[
				'label' => __( 'Zoom', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'map_marker',
			[
				'label' => __( 'Map Marker', 'tahex_plg' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 40,
						'max' => 1440,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ 'px', 'vh' ],
				'selectors' => [
					'{{WRAPPER}} iframe' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render google maps widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$dynamic_map_id = rand(1245,256398);
		$marker = wp_get_attachment_image_url( $settings['map_marker']['id'], 'thumbnail' );
		$address = $settings['address'];
		if( empty ( $address ) ){
			return;
		}		
		
		if ( 0 === absint( $settings['zoom']['size'] ) ) {
			$zoom = $settings['zoom']['size'] = 10;
		}
		
		
		$zoom = $settings['zoom']['size'];
		$latitude = $settings['latitude'];
		$longitude = $settings['longitude'];
		$mapTypeId = $settings['mapTypeId'];
		$content = $settings['content'];
		
		$map_api_key = esc_html( get_option( 'gmap_api_key' ) );
		
		$params = [
			rawurlencode( $address ),
			absint( $zoom ),
			esc_attr( $address ),$latitude,$longitude
		];
		
		if ( $map_api_key ) {
			$params[] = $map_api_key;

			$url = 'https://www.google.com/maps/embed/v1/place?key=%4$s&q=%1$s&amp;zoom=%2$d';
		} else {
			$url = 'https://maps.google.com/maps?q=%1$s&amp;t=m&amp;z=%2$d&amp;output=embed&amp;iwloc=near';
		}
		

		?>	
		
			<script type="text/javascript">
			
			(function ($) {
				"use strict";

			   jQuery(document).ready(function($){ 


				/* ======================  Google Map ====================== */
									 
						 $('#map-<?php echo $dynamic_map_id;?>')
						  .gmap3({
							address:"<?php echo $address; ?>",
							center: [<?php echo $latitude;?>,<?php echo $longitude;?>],
							zoom:<?php echo $zoom;?>,
							scrollwheel:false,
							mapTypeId: "<?php echo $mapTypeId;?>",
							
						}) 
						  
						//marker with animation

						.marker({				
							position:[<?php echo $latitude;?>,<?php echo $longitude;?>],
							icon:'<?php echo $gmap_marker;?>'	 

						})   
						
									
					//infowindow
															
						.infowindow({
							content:'<span class="content-text">
									<?php echo $content;?>
									'</span>',
							
						})
						
						.then(function (infowindow) {
							var map = this.get(0);
							var marker = this.get(1);
							 var el = $('.gm-style-iw');
							el.siblings().css('visibility', 'hidden');
							marker.addListener('click', function() {
							  infowindow.open(map, marker);
							});
						}) 
						
				
						// map style
										
				.styledmaptype(
					"<?php echo $mapTypeId;?>",
					[
					  {"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},
					  {"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},
					  {"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},
					  {"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},
					  {"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},
					  {"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},
					  {"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},
					  {"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},
					  {"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},
					  {"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},
					  {"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},
					  {"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},
					  {"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}
					],
					{name: "Shades of Grey"}
				  )
				  
				 });	

			}(jQuery));	
		</script>

		<div class="map-area">		
			<div id="map-<?php echo $dynamic_map_id;?>">				
				<iframe src="<?php echo vsprintf( $url, $params ); ?>" frameborder="0"></iframe>
			</div>				
		</div><!--map-area -->
		

		<?php
	}

	/**
	 * Render google maps widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 2.9.0
	 * @access protected
	 */
	protected function content_template() {}
}
