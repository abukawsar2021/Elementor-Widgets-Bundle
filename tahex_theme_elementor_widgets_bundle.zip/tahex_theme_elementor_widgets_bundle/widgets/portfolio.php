<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Portfolio extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-portfolio';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Portfolio', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'fa fa-clone';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Portfolio Settings.', 'tahex_plg' ),
			]
		);
        

        $this->add_control(
			'show_filter',
			[
				'label' => __( 'Show Filter', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'show' => __( 'Show', 'tahex_plg' ),
				'hide' => __( 'Hide', 'tahex_plg' ),
				'default' => 'yes',
			]
	    );

		$this->add_control(
			'port_style',
			[
				'label' => __( 'Style', 'tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'1' => __( 'Style One', 'tahex_plg' ),
					'2' => __( 'Style Two', 'tahex_plg' ),
					'3' => __( 'Style Three', 'tahex_plg' ),
				],
				'default' => '1',
			]
		);
		 	
		$this->add_responsive_control(
			'filter_align',
			[
				'label' => __( 'Filter Alignment', 'tahex_plg' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'tahex_plg' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'tahex_plg' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'tahex_plg'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .work-menu' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'port_item',
			[
				'label' => __( 'Item to display', 'tahex_plg' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '8',
			]
		);
		
		$this->add_control(
			'sort_cat',
			[
				'label' => __( 'Sort Portfolio by Portfolio Category', 'tahex_plg' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => __( 'Yes', 'tahex_plg' ),
				'label_off' => __( 'No', 'tahex_plg' ),
				'return_value' => 'yes',
			]
		);
		
		 $this->add_control(
			'blog_cat',
			[
				'label'   => __( 'Category to Show', 'tahex_plg' ),
				'type'    => Controls_Manager::SELECT2, 'options' => tax_choice(),
				'condition' => [
					'sort_cat' => 'yes',
				],
				'multiple'   => 'true',
			]
		); 
		
		 $this->add_control(
			'port_order',
			[
				'label' => __( 'Orders', 'tahex_plg' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'DESC' => __( 'Descending', 'tahex_plg' ),
					'ASC' => __( 'Ascending', 'tahex_plg' ),
					'rand' => __( 'Random', 'tahex_plg' ),
				],
				'default' => 'DESC',
			]
		); 
		
		
		 $this->add_control(
			'num_of_column',
			[
				'label' => __( 'Columns', 'tahex_plg' ),
				'type' => Controls_Manager::SELECT,		
				'options' => [
					'2'  => __( 'Two Columns', 'tahex_plg' ),
					'3'  => __( 'Three Columns', 'tahex_plg' ),
					'4'  => __( 'Four Columns', 'tahex_plg' ),
				],
				'default' => '3',
			]
		);
		
		
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'port_filter_style',
			[
				'label' => __( 'Filter Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'filter_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'filter_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'filter_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu ' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		
      /* $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'Border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} ul.work-menu',
			]
		); */
		
		$this->add_control(
			'filter_list_margin',
			[
				'label' => __( 'List Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'filter_list_padding',
			[
				'label' => __( 'List Paddiing', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'filter_list_anchor_padding',
			[
				'label' => __( 'Link Paddiing', '' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Link Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} ul.work-menu li>a',
			]
		);
		
		
		$this->add_control(
			'filter_list_anchor_b_radius',
			[
				'label' => __( 'Link Border Radius', '' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'filter_list_anchor_b_color',
			[
				'label' => __( 'Link Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_control(
			'filter_list_anchor_bg_color',
			[
				'label' => __( 'Link BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		
		
		$this->add_control(
			'filter_list_anchor_b_color_hover',
			[
				'label' => __( 'Link Hover Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_control(
			'filter_list_anchor_b_color_hover_bg_color',
			[
				'label' => __( 'Link Hover BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_list_anchor_b_color_selected',
			[
				'label' => __( 'Link Selected Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a.selected' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_control(
			'filter_list_anchor_bg_color_selected',
			[
				'label' => __( 'Link Selected BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} ul.work-menu li>a.selected' => 'background-color: {{VALUE}};',
				],
			]
		);
		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'filter_anchor_typography',
				'label' => __( 'Typography', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} ul.work-menu li>a',
			]
		);
		
		
		
		$this->end_controls_section();
		
		
				$this->start_controls_section(
			'item_style',
			[
				'label' => __( 'Single Item Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'p_item_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .element-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'p_item_padding',
			[
				'label' => __( 'Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .element-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'p_item_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-work-item-wrapper' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'p_item_br_radius',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-work-item-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		
		
		$this->add_control(
			'p_item_overlay',
			[
				'label' => __( 'Item Overlay', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-work-item-wrapper:after' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'item_title_style',
			[
				'label' => __( 'Item Title Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'p_item_title',
			[
				'label' => __( 'Title Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-work-item-wrapper figcaption.image-caption ul > li.work-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'p_item_title_bg_color',
			[
				'label' => __( 'Title BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-work-item-wrapper figcaption.image-caption ul > li.work-title' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[   
			    'label' => __( 'Typography', 'tahex_plg' ),
				'name' => 'p_item_title_typo',				
				'selector' => '{{WRAPPER}} .single-work-item-wrapper figcaption.image-caption ul > li.work-title',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'item_cat_style',
			[
				'label' => __( 'Item Category Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'p_item_cat_pdt',
			[
				'label' => __( 'Padding Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.cat-name' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'p_item_cat_margin',
			[
				'label' => __( 'Margin', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.cat-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'p_item_cat_color',
			[
				'label' => __( 'Category Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.cat-name' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[   
			    'label' => __( 'Category Typography', 'tahex_plg' ),
				'name' => 'p_item_cat_name_typo',				
				'selector' => '{{WRAPPER}} .single-work-item-wrapper figcaption.image-caption ul > li > a.cat-name',
			]
		);

		$this->add_control(
			'p_item_cat_bg_color',
			[
				'label' => __( 'Category BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.cat-name' => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'item_icon_style',
			[
				'label' => __( 'Item Icon Style.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'p_icon',
			[
				'label' => __( 'Port Icon', 'text-domain' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'far fa-image',
				],				
			]
		);
		
		$this->add_control(
			'p_item_icon_color',
			[
				'label' => __( 'Icon Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.work-link' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'p_item_icon_bg_color',
			[
				'label' => __( 'Icon BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.work-link' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.work-link',
			]
		);

		
		$this->add_control(
			'p_item_icon_bg_radius',
			[
				'label' => __( 'Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.work-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->add_control(
			'p_item_icon_hover_color',
			[
				'label' => __( 'Icon Hover Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.work-link:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'p_item_icon_hover_bg_color',
			[
				'label' => __( 'Icon Hover BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a.work-link:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'p_item_icon_size',
			[
				'label' => __( 'Size', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} figure.single-work-item-wrapper figcaption.image-caption ul > li > a i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		
		$this->end_controls_section();
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();?>

    
		<?php	
		   if('yes' === $settings['show_filter']):	 
		?>	
		<ul class="work-menu list-unstyled">
			<li>
			<a href="#" data-filter="*" class="selected"><?php esc_html_e('All','tahex_plg');?></a>
			</li>		
			<?php	  
				$tahex_taxonomy = 'portfolio_category';
				$tahex_tax_terms =  get_terms( $tahex_taxonomy  );
			   
				if(!empty($tahex_tax_terms && !is_wp_error($tahex_taxonomy))){			   
				   foreach($tahex_tax_terms as $tahex_term ){?>
					<li> 
						<a href="#" data-filter=".<?php echo strtolower( preg_replace ( '/[^a-zA-Z]+/','-', $tahex_term->name ) ); ?> ">
						   <?php echo $tahex_term->name; ?>
						</a>
					</li>
				<?php }?>		   
			<?php } ?>	  	 	 
		</ul><!-- work-menu -->	  
		<?php endif; ?>
		
   		<div class="project-items clearfix 
		       <?php 
			        if($settings['port_style'] == '2'){echo 'format-two';}
			        elseif($settings['port_style'] == '3'){echo 'format-three';}
			   
			   ?>">
			<?php 
				if ($settings['port_order'] != 'rand') {
					$order = 'order';
					$ord_val = $settings['port_order'];
				} else {
					$order = 'orderby';
					$ord_val = 'rand';
				}
				
				if ( $settings['sort_cat']  == 'yes' ) {
					$tahex_port = new \WP_Query(array(
						'posts_per_page'  => $settings['port_item'],
						'post_type' =>  'portfolio', 'tahex_plg',
						$order       =>  $ord_val,
						'tax_query' => array(
							array(
								'taxonomy' => 'portfolio_category',   // taxonomy name
								'field' => 'term_id',
								'terms' => $settings['blog_cat'],  
							
							)
						)
					));  
								
				} else {
					$tahex_port = new \WP_Query(array(
						'posts_per_page'   => $settings['port_item'],
						'post_type' =>  'portfolio', 'tahex_plg',
						$order       =>  $ord_val
					)); 
				}
				
				
				if ($tahex_port->have_posts()) : while  ($tahex_port->have_posts()) : $tahex_port->the_post();
				global $post ;
				
			?>
			<?php $tahex_tax_terms = get_the_terms( get_the_ID(), 'portfolio_category' );?>	   
			<div class="<?php if($settings['num_of_column'] == '3'){echo "col-md-4";} else if($settings['num_of_column'] == '2'){echo "col-md-6";} else {echo "col-md-3";}?>		
				element-item <?php foreach($tahex_tax_terms as $tahex_tax_term){ 
				  echo strtolower(preg_replace('/[^a-zA-Z]+/','-',$tahex_tax_term->name)).' '; 
				}			 
				$post_classes = get_post_class(); 
				foreach( $post_classes as $post_class ){
					 echo esc_attr( $post_class ). " ";}?>" id="post-<?php the_ID();?>">
                <div class="project-inner">				 
					<figure class="single-work-item-wrapper" data-link="work1.html">
						<img class="img-responsive" 
						 src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'full');?>" alt="<?php echo esc_attr(strtolower(get_the_title(get_the_ID())))?>" />
						<figcaption class="image-caption">			
							<ul class="list-unstyled">
								<li class="work-title"><?php the_title(); ?></li>
								<li>
									<a class="work-link" href="#" data-link="work1.html"> 
									     <i class="<?php echo esc_attr ( $settings['p_icon']['value'] ); ?>"></i>
									</a>
								</li>
								<li><a class="cat-name" href="<?php the_permalink();?>">
									<p> 
									<?php 
										$tahex_taxonomy = 'portfolio_category';
										$tahex_term_list_for_post = wp_get_post_terms($post->ID,$tahex_taxonomy);
										$tahex_post_cat_lists = array();
										foreach($tahex_term_list_for_post as $tahex_term_list){
										$tahex_post_cat_lists[] = $tahex_term_list->name;
										}
										echo implode(', ', $tahex_post_cat_lists);
									?>  					
									</p>				
								</li></a>
							</ul>						
						</figcaption><!-- figcaption -->			
					</figure><!-- figure -->
				</div><!-- project-inner -->	
			</div><!--/element-item -->	
					
			<?php endwhile; else: ?>
			<div class="alert alert-warning">
				<?php _e('There is no Portfolio Post Found. You need to  choose the portfolio category to show or create at least 1 portfolio post first.','gerlong-plg'); ?>
			</div>
			<?php endif;  wp_reset_postdata();  ?>                          
                            
        </div><!--/.project-items-->
                        
		<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

