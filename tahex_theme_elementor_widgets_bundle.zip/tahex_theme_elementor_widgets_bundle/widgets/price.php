<?php
namespace TahexPlugin\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * @since 1.1.0
 */

class Tahex_Price extends Widget_Base {


    // Widget Name

	public function get_name() {
		return 'tahex-price-table';
	}
	
	
    // Widget Title
	
	public function get_title() {
		return __( 'Tahex Price Table', 'tahex_plg' );
	}
	
    // Widget icon
	
	public function get_icon() {
		return 'eicon-price-table';
	}
	
	
	
    // Widget Category
	
	public function get_categories() {
		return [ 'tahex-general-elements' ];
	}
	
	
	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'team_section_content',
			[
				'label' => __( 'Price Table Settings.', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'pricing_table_title',
			[
				'label' => __( 'Title', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( '', 'tahex_plg' ),
			]
		);
		
		$this->add_control(
			'pricing_table_cur_icon',
			[
				'label' => __( 'Currency Icon', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		
		$this->add_control(
			'pricing_table_cur_price_num',
			[
				'label' => __( 'Price Number', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0.50,
				'max' => 1000.00,
			]
		);

		
		$this->add_control(
			'pricing_table_time',
			[
				'label' => __( 'Duration', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( '', 'tahex_plg' ),
			]
		);
      
	    $repeater = new \Elementor\Repeater();
	  
	    $repeater->add_control(
			'pricint_table_content_title', [
				'label' => __( 'Title', 'tahex_plg' ),
				'type' =>Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'pricint_table_content_list',
			[
				'label' => __( 'Content List', 'tahex_plg' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'pricint_table_content_title' => __( '10 Emails', 'tahex_plg' ),
					],
					[
						'pricint_table_content_title' => __( '1GB Bandwidth', 'tahex_plg' ),
					],
					[
						'pricint_table_content_title' => __( 'Free Updates', 'tahex_plg' ),
					],
					
					[
						'pricint_table_content_title' => __( '<del> Unlimited Downloads </del>', 'tahex_plg' ),
					],
				],
				'title_field' => '{{{ pricint_table_content_title }}}',
			]
		);

	  
	  $this->add_control(
			'pricing_table_btn_text',
			[
				'label' => __( 'Button Text', 'tahex_plg' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( '', 'tahex_plg' ),
			]
		);

		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'pricing_table_style',
			[
				'label' => __( 'Price Table Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'pricing_table_height',
			[
				'label' => __( 'Table Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'pricing_table_padding',
			[
				'label' => __( 'Tabel Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'pricing_table_content_list_padding',
			[
				'label' => __( 'List Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .single-pricing-body ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_border',
				'label' => __( 'Table Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-pricing-table-wrapper',
			]
		);
		
		$this->add_control(
			'pricing_table_border_radius',
			[
				'label' => __( 'Table Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_border_on_hover',
				'label' => __( 'Table Border On Hover', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .active.single-pricing-table-wrapper',
			]
		);
		
		
		$this->add_control(
			'pricing_table_text_color',
			[
				'label' => __( 'Table Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .single-pricing-body' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'pricing_table_bg_color',
			[
				'label' => __( 'Table BG Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .single-pricing-body' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'pricing_table_text_color_on_hover',
			[
				'label' => __( 'Table Text Hover Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .active.single-pricing-table-wrapper .single-pricing-body' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'pricing_table_bg_hover_color',
			[
				'label' => __( 'Table BG Hover Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .active.single-pricing-table-wrapper .single-pricing-body' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();
		
         $this->start_controls_section(
			'pricing_table_button_style',
			[
				'label' => __( 'Price Table Button Style', 'tahex_plg' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'pricing_table_button_margin_top',
			[
				'label' => __( 'Margin Top', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .pricing-content ul li a.select-btn' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'pricing_table_button_height',
			[
				'label' => __( 'Height', 'tahex_plg' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .pricing-content ul li a.select-btn' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'pricing_table_button_padding',
			[
				'label' => __( 'Tabel Padding', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .pricing-content ul li a.select-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'pricing_table_button_text_color',
			[
				'label' => __( 'Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .pricing-content ul li a.select-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'pricing_table_button_bg_color',
			[
				'label' => __( 'Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .pricing-content ul li a.select-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		
		$this->add_control(
			'pricing_table_button_hover_text_color',
			[
				'label' => __( 'Hover Text Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .active.single-pricing-table-wrapper .single-pricing-body .pricing-content ul li a.select-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'pricing_table_button_hover_bg_color',
			[
				'label' => __( 'Hover Background Color', 'tahex_plg' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .active.single-pricing-table-wrapper .single-pricing-body .pricing-content ul li a.select-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'pricing_table_button_border',
				'label' => __( 'Table Button Border', 'tahex_plg' ),
				'selector' => '{{WRAPPER}} .single-pricing-table-wrapper .single-pricing-body .pricing-content ul li a.select-btn',
			]
		);
		
		$this->add_control(
			'pricing_table_button_border_radius',
			[
				'label' => __( 'Table Button Border Radius', 'tahex_plg' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .single-pricing-table-wrapper .single-pricing-body .pricing-content ul li a.select-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->end_controls_section();
		
		

	}

		
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	 
	protected function render() {
    $settings = $this->get_settings_for_display();
	$dynamic_id = rand(2154,25893);
	?>
	     
		    <div id="<?php echo $dynamic_id;?>" class="single-pricing-table-wrapper">
				<div class="single-pricing-body">
					<div class="pricing-header">
						<ul>
							<li class="heading"> <?php echo ( $settings['pricing_table_title'] );?> </li>
							<li><span class="currency"> 
							<i class="<?php echo ( $settings['pricing_table_cur_icon']['value'] );?>"></i>
							<?php echo ( $settings['pricing_table_cur_price_num'] );?> 
							</span> / <span class="time"> <?php echo ( $settings['pricing_table_time'] );?> </span></li>
						</ul>
					</div><!-- pricing-header -->		
					<div class="pricing-content">
						<ul>
						
						<?php foreach($settings['pricint_table_content_list'] as $list):?>
						
							<li> <?php echo ( $list['pricint_table_content_title'] );?> </li>
							
						<?php endforeach;?>	
							<li><a class="select-btn" href="#"> <?php echo ( $settings['pricing_table_btn_text'] );?></a></li>
						</ul><!-- ul -->
					</div><!-- pricing-content -->								
				</div><!-- single-pricing-body -->
			</div><!-- single-pricing-table-wrapper -->
				
                        
		<?php 
		
	}
	
	
/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {

	}
}

