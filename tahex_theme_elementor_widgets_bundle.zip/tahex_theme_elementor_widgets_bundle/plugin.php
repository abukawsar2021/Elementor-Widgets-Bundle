<?php
namespace TahexPlugin;

use TahexPlugin\Widgets\Tahex_Logo;
use TahexPlugin\Widgets\Tahex_Menu;
use TahexPlugin\Widgets\Tahex_Slider;
use TahexPlugin\Widgets\Tahex_Portfolio;
use TahexPlugin\Widgets\Tahex_Ticker_Slider;
use TahexPlugin\Widgets\Tahex_Team;
use TahexPlugin\Widgets\Tahex_Price;
use TahexPlugin\Widgets\Tahex_Counter;
use TahexPlugin\Widgets\Tahex_Brand;
use TahexPlugin\Widgets\Tahex_Testimonial;
use TahexPlugin\Widgets\Tahex_Tabs;
use TahexPlugin\Widgets\Tahex_Google_Map;

 
 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}



/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 */


class TahexPlugin{

/**
* Constructor
*
*/

public function __construct(){
$this->script_files_loading();
	
}


private function script_files_loading(){
	add_action( 'elementor/widgets/widgets_registered', [ $this, 'widget_register' ] );	
	add_action( 'wp_enqueue_scripts', [ $this, 'widget_scripts_enqueue' ] );		
}


public function widget_scripts_enqueue() {   		
wp_enqueue_script( 'menu', plugins_url( 'widgets/js/menu.js', __FILE__ ), [ 'jquery'], null, true ); 
wp_enqueue_script( 'owl-carousel', plugins_url( 'widgets/js/owl.carousel.min.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'imagesloaded-pkgd', plugins_url( 'widgets/js/imagesloaded.pkgd.min.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'isotope', plugins_url( 'widgets/js/isotope.pkgd.min.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'portfolio', plugins_url( 'widgets/js/portfolio.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'ticker', plugins_url( 'widgets/js/ticker.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'ticker-active', plugins_url( 'widgets/js/ticker-active.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'price-hover', plugins_url( 'widgets/js/price-hover.js', __FILE__ ), [ 'jquery'], null, true ); 								
wp_enqueue_script( 'jQuerySimpleCounter', plugins_url( 'widgets/js/jQuerySimpleCounter.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'easing', plugins_url( 'widgets/js/jquery.easing.min.js', __FILE__ ), [ 'jquery'], null, true ); 				 				
wp_enqueue_script( 'testimonial', plugins_url( 'widgets/js/testimonial.js', __FILE__ ), [ 'jquery'], null, true );  				
wp_enqueue_script( 'fancybox-active', plugins_url( 'widgets/js/fancybox-active.js', __FILE__ ), [ 'jquery'], null, true );
wp_enqueue_script( 'fancybox', plugins_url( 'widgets/js/jquery.fancybox.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'about-slider', plugins_url( 'widgets/js/about-slider.js', __FILE__ ), [ 'jquery'], null, true ); 				
wp_enqueue_script( 'gmap3', plugins_url( 'widgets/js/gmap3.min.js', __FILE__ ), [ 'jquery'], null, true ); 				
}



public function widget_register(){
$this->includes_widgets_files();
$this->includes_widgets();
	
	
}



private function includes_widgets_files(){	
require_once( __DIR__ . '/widgets/logo.php' );							
require_once( __DIR__ . '/widgets/menu.php' );				
require_once( __DIR__ . '/widgets/slider.php' );
require_once( __DIR__ . '/widgets/portfolio.php' );			
require_once( __DIR__ . '/widgets/ticker-slider.php' );			
require_once( __DIR__ . '/widgets/team.php' );			
require_once( __DIR__ . '/widgets/price.php' );			
require_once( __DIR__ . '/widgets/counter.php' );			
require_once( __DIR__ . '/widgets/brand.php' );			
require_once( __DIR__ . '/widgets/testimonial.php' );			
require_once( __DIR__ . '/widgets/tabs.php' );						
require_once( __DIR__ . '/widgets/gmap.php' );						
}


private function includes_widgets(){
	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Menu() );		
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Logo() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Slider() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Portfolio() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Ticker_Slider() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Team() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Price() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Counter() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Brand() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Testimonial() );	
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Tabs() );		
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Tahex_Google_Map() );		
		
}


}
new TahexPlugin();