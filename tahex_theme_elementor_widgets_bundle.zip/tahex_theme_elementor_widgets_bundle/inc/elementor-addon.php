<?php

//add new category elementor
add_action( 'elementor/elements/categories_registered', 'add_custom_categories' );
function add_custom_categories( $elements_manager ) {

	$elements_manager->add_category(
		'tahex-general-elements',
		[
			'title' => __( 'Tahex General Elements', 'tahex_plg' ),
			'icon' => 'fa fa-plug',
		]
	);

}

//display menu list
  function navmenu_navbar_menu_choices(){
	$menus = wp_get_nav_menus();
	$items = array();
	$i     = 0;
	foreach ( $menus as $menu ) {
		if ( $i == 0 ) {
			$default = $menu->slug;
			$i ++;
		}
		$items[ $menu->slug ] = $menu->name;
	}
	return $items;
}



//display category display category blog list
 /*  function category_choice() {
    $categories = get_categories( );
	$blogs = array();
	$i     = 0;
	foreach ( $categories as $category ) {
		if ( $i == 0 ) {
			$default = $category->name ;
			$i ++;
		}
		$blogs[ $category->term_id ] = $category->name;
	}
	return $blogs;
}   */



//display taxnonomy
 function tax_choice() {
    $categories = get_terms('portfolio_category' );
	$blogs = array();
	$i     = 0;
	foreach ( $categories as $category ) {
		if ( $i == 0 ) {
			$default = $category->name ;
			$i ++;
		}
		$blogs[ $category->term_id ] = $category->name;
	}
	return $blogs;
} 








 