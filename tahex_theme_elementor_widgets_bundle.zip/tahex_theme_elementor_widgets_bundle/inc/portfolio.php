<?php

// Register Post Type  //

function tahex_portfolio_post_type() {
	 
    $labels = array(
        'name'                  => _x( 'Portfolios', 'tahex_plg' ),
        'singular_name'         => _x( 'Portfolio', 'tahex_plg' ),
        'add_new'               => __( 'Add New', 'tahex_plg' ),
        'add_new_item'          => __( 'Add New Portfolio', 'tahex_plg' ),
        'new_item'              => __( 'New Portfolio', 'tahex_plg' ),
        'edit_item'             => __( 'Edit Portfolio', 'tahex_plg' ),
        'view_item'             => __( 'View Portfolio', 'tahex_plg' ),
        'search_items'          => __( 'Search Portfolio', 'tahex_plg' ),
        'not_found'             => __( 'No Portfolio found.', 'tahex_plg' ),
        'not_found_in_trash'    => __( 'No Portfolio found in Trash.', 'tahex_plg' ),
        'featured_image'    => __( 'Set Portfolio Image', 'tahex_plg' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'rewrite'            => array( 'slug' => 'portfolio' ),
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
		'menu_icon'           => 'dashicons-index-card',
		'menu_position' => 5,
		'exclude_from_search' => true 
    );
   
  register_post_type( 'portfolio', $args ); 
   
}
 
add_action( 'init', 'tahex_portfolio_post_type' );


// Register taxonomies //

function tahex_portfolio_taxonomies() {
 
    $labels = array(
        'name'              => _x( 'Portfolio Categories', 'taxonomy general name' ),
        'singular_name'     => _x( 'Portfolio Category', 'taxonomy singular name' ),
        'search_items'      => __( 'Search Portfolio' ),
        'all_items'         => __( 'All Portfolio'),
        'parent_item'       => __( 'Parent Portfolio'),
        'parent_item_colon' => __( 'Parent Portfolio Category'),
        'edit_item'         => __( 'Edit Portfolio Category'),
        'update_item'       => __( 'Update Portfolio Category'),
        'add_new_item'      => __( 'Add New Portfolio Category'),
        'new_item_name'     => __( 'New Portfolio Category'),
        'menu_name'         => __( 'Portfolio Categories' ),
    );
 
    $args = array(
        'labels'            => $labels,
        'hierarchical'      => true,
    );
    register_taxonomy( 'portfolio_category', 'portfolio', $args );
 
}
add_action('init','tahex_portfolio_taxonomies', 0 ); 


