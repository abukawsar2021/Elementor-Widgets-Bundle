<?php
/**
 * Plugin Name: Tahex Plugin Bundle
 * Description: This is a onepage website plugin
 * Plugin URI:  https://abushop.com/
 * Version:     1.0.0
 * Author:      abuShop
 * Author URI:  https://abushop.com/
 * Text Domain: tahex_plg
 */
 
 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'TAHEX_VERSION', '3.3.1' );
define( 'TAHEX__FILE__', __FILE__ );
define( 'TAHEX_URL', plugins_url( '/', TAHEX__FILE__  ) );


/**
 * Load Tahex textdomain.
 */
function tahex_plg_loaded(){
	// load localized file
	load_plugin_textdomain( 'tahex_plg' );
	
	// require the main plugin file
	require(__DIR__ . '/plugin.php');	
}
add_action('plugins_loaded','tahex_plg_loaded');


/**
 * Fail to load 
 */

function tahex_plg_fail_load_out_of_date() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	$file = 'elementor/elementor.php';

	$upgrade_link_url = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $file, 'upgrade-plugin_' . $file );
	$message = '<p>' . __( 'Tahex Plugin is not working because you are using an old version of Elementor.', 'tahex_plg' ) . '</p>';
	$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $upgrade_link_url, __( 'Update Elementor Now', 'tahex_plg' ) ) . '</p>';

	echo '<div class="error">' . $message . '</div>';
}



//include elementor addon
include('inc/elementor-addon.php');

//include portfolio custom post type
include('inc/portfolio.php');

//include custom header


//include custom footer


//include single portfolio


//include custom widgets


//included one click importer



// admin style scripts


/* function admin_style(){	
	wp_enqueue_style('admin-style', TAHEX_URL . 'css/admin.css');	
}
add_action('admin_enqueue_scripts','admin_style');
 */
 
 

// plugin translation 


function tahex_textdomain_translation(){
	load_plugin_textdomain('tahex_plg', false, dirname(plugin_basename(__FILE__)) . '/languages');	
}
add_action('after_setup_theme','tahex_textdomain_translation');








